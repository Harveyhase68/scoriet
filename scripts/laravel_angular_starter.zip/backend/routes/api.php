<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\UiLanguageController;
use App\Http\Controllers\Api\PasswordResetController;
use App\Http\Controllers\Api\ProfileController;
use App\Http\Controllers\Api\TwoFactorController;
{:for nmaxtables:}
use App\Http\Controllers\Api\{:filesingularpascalcase:}Controller;
{:endfor:}
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public routes
|--------------------------------------------------------------------------
| Login itself is handled by Passport's OAuth2 password grant at
| POST /oauth/token (registered automatically by the Passport package).
*/
Route::prefix('auth')->group(function () {
    Route::post('register', [AuthController::class, 'register']);
    Route::post('forgot-password', [PasswordResetController::class, 'sendResetLink']);
    Route::post('reset-password', [PasswordResetController::class, 'reset']);
});

// Available before login too, so the language switcher works on the auth pages.
Route::get('ui-languages/active', [UiLanguageController::class, 'active']);

/*
|--------------------------------------------------------------------------
| Protected routes (require a valid Bearer access token)
|--------------------------------------------------------------------------
*/
Route::middleware('auth:api')->group(function () {
    // Current user + session
    Route::get('auth/me', [AuthController::class, 'me']);
    Route::post('auth/logout', [AuthController::class, 'logout']);

    // Profile
    Route::put('profile', [ProfileController::class, 'update']);
    Route::put('profile/language', [ProfileController::class, 'updateLanguage']);
    Route::put('profile/password', [ProfileController::class, 'updatePassword']);
    Route::post('profile/avatar', [ProfileController::class, 'uploadAvatar']);
    Route::delete('profile/avatar', [ProfileController::class, 'deleteAvatar']);

    // Two-factor authentication
    Route::prefix('2fa')->group(function () {
        Route::get('status', [TwoFactorController::class, 'status']);
        Route::post('enable', [TwoFactorController::class, 'enable']);
        Route::post('confirm', [TwoFactorController::class, 'confirm']);
        Route::post('verify', [TwoFactorController::class, 'verify']);
        Route::post('check-device', [TwoFactorController::class, 'checkDevice']);
        Route::post('disable', [TwoFactorController::class, 'disable']);
        Route::post('cancel-setup', [TwoFactorController::class, 'cancelSetup']);
        Route::post('recovery-codes', [TwoFactorController::class, 'regenerateRecoveryCodes']);
        Route::get('trusted-devices', [TwoFactorController::class, 'trustedDevices']);
        Route::delete('trusted-devices/{deviceId}', [TwoFactorController::class, 'removeTrustedDevice']);
        Route::delete('trusted-devices', [TwoFactorController::class, 'removeAllTrustedDevices']);
    });

    // Generated CRUD + print routes, one block per active schema table.
{:for nmaxtables:}
    Route::get('{:filename:}', [{:filesingularpascalcase:}Controller::class, 'index']);
    Route::get('{:filename:}/report', [{:filesingularpascalcase:}Controller::class, 'reportList']);
    Route::post('{:filename:}', [{:filesingularpascalcase:}Controller::class, 'store']);
    Route::get('{:filename:}/{{:filesingular:}}', [{:filesingularpascalcase:}Controller::class, 'show']);
    Route::put('{:filename:}/{{:filesingular:}}', [{:filesingularpascalcase:}Controller::class, 'update']);
    Route::delete('{:filename:}/{{:filesingular:}}', [{:filesingularpascalcase:}Controller::class, 'destroy']);
    Route::get('{:filename:}/{{:filesingular:}}/report', [{:filesingularpascalcase:}Controller::class, 'report']);
{:endfor:}
});
