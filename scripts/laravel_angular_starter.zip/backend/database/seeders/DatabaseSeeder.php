<?php

namespace Database\Seeders;

use App\Models\UiLanguage;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        User::factory()->create([
            'name' => 'Test User',
            'email' => 'test@example.com',
        ]);

        UiLanguage::updateOrCreate(['code' => 'en'], [
            'name' => 'English', 'native_name' => 'English', 'flag' => '🇬🇧',
            'is_active' => true, 'is_default' => true, 'sort_order' => 1,
        ]);
        UiLanguage::updateOrCreate(['code' => 'de'], [
            'name' => 'German', 'native_name' => 'Deutsch', 'flag' => '🇩🇪',
            'is_active' => true, 'is_default' => false, 'sort_order' => 2,
        ]);
    }
}
