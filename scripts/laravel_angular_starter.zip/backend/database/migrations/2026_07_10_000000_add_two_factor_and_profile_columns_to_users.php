<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            // Profile
            $table->string('avatar_path')->nullable()->after('email');

            // Two-factor authentication (ported from scoriet)
            $table->string('two_factor_secret')->nullable();
            $table->boolean('two_factor_enabled')->default(false);
            $table->timestamp('two_factor_confirmed_at')->nullable();
            $table->text('two_factor_recovery_codes')->nullable();
            $table->text('two_factor_trusted_devices')->nullable();
            $table->timestamp('two_factor_last_verified_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn([
                'avatar_path',
                'two_factor_secret',
                'two_factor_enabled',
                'two_factor_confirmed_at',
                'two_factor_recovery_codes',
                'two_factor_trusted_devices',
                'two_factor_last_verified_at',
            ]);
        });
    }
};
