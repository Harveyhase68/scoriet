<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Cross-Origin Resource Sharing (CORS) Configuration
    |--------------------------------------------------------------------------
    |
    | Paths include the OAuth2 token endpoint (/oauth/*) in addition to the
    | API, because the Angular SPA logs in by calling POST /oauth/token
    | directly. Authentication uses Bearer tokens (not cookies), so
    | supports_credentials stays false.
    |
    */

    'paths' => ['api/*', 'oauth/*', 'storage/*'],

    'allowed_methods' => ['*'],

    'allowed_origins' => [
        env('FRONTEND_URL', 'http://localhost:4200'),
        'http://localhost:4200',
        'http://127.0.0.1:4200',
    ],

    'allowed_origins_patterns' => [],

    'allowed_headers' => ['*'],

    'exposed_headers' => [],

    'max_age' => 0,

    'supports_credentials' => false,

];
