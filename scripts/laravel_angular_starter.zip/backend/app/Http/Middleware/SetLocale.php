<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Symfony\Component\HttpFoundation\Response;

/**
 * Resolves the app locale for the current request: the authenticated user's
 * saved preference, falling back to the Accept-Language header, falling
 * back to the app default. Only affects backend-generated strings (e.g.
 * validation messages) — the Angular UI text is translated client-side.
 */
class SetLocale
{
    private const SUPPORTED = ['en', 'de'];

    public function handle(Request $request, Closure $next): Response
    {
        $locale = $request->user()?->language
            ?? substr((string) $request->getPreferredLanguage(self::SUPPORTED), 0, 2);

        if (in_array($locale, self::SUPPORTED, true)) {
            App::setLocale($locale);
        }

        return $next($request);
    }
}
