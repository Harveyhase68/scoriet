<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use BaconQrCode\Renderer\Image\SvgImageBackEnd;
use BaconQrCode\Renderer\ImageRenderer;
use BaconQrCode\Renderer\RendererStyle\RendererStyle;
use BaconQrCode\Writer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use PragmaRX\Google2FA\Google2FA;

/**
 * TOTP two-factor authentication. Ported from scoriet's TwoFactorController,
 * simplified for a first-party SPA: the scoriet-specific device-bound token
 * revocation (which relied on a custom device_id column on oauth_access_tokens)
 * has been removed. Trusted devices are still tracked in the user record.
 */
class TwoFactorController extends Controller
{
    protected Google2FA $google2fa;

    public function __construct()
    {
        $this->google2fa = new Google2FA;
    }

    /**
     * Current 2FA status for the authenticated user.
     */
    public function status(Request $request)
    {
        return response()->json([
            'two_factor' => $request->user()->getTwoFactorStatus(),
        ]);
    }

    /**
     * Begin enabling 2FA: generate a secret and the QR code to scan.
     */
    public function enable(Request $request)
    {
        $user = $request->user();

        if (! $request->has('password') || ! Hash::check($request->password, $user->password)) {
            return response()->json(['message' => 'The provided password is incorrect.'], 422);
        }

        if ($user->hasTwoFactorEnabled()) {
            return response()->json(['message' => 'Two-factor authentication is already enabled.'], 400);
        }

        $secret = $this->google2fa->generateSecretKey();

        $user->two_factor_secret = $secret;
        $user->two_factor_enabled = false;
        $user->two_factor_confirmed_at = null;
        $user->save();

        $qrCodeUrl = $this->google2fa->getQRCodeUrl(
            config('app.name', 'Laravel'),
            $user->email,
            $secret
        );

        $renderer = new ImageRenderer(new RendererStyle(200), new SvgImageBackEnd);
        $qrCodeSvg = (new Writer($renderer))->writeString($qrCodeUrl);

        return response()->json([
            'message' => 'Scan the QR code with your authenticator app, then confirm with a code.',
            'secret' => $secret,
            'qr_code_svg' => $qrCodeSvg,
            'qr_code_url' => $qrCodeUrl,
        ]);
    }

    /**
     * Confirm the 2FA setup with a code from the authenticator app.
     */
    public function confirm(Request $request)
    {
        $request->validate([
            'code' => 'required|string|size:6',
            'trust_device' => 'nullable|boolean',
            'device_id' => 'nullable|string',
            'browser' => 'nullable|string',
        ]);

        $user = $request->user();

        if (! $user->isTwoFactorPending()) {
            return response()->json(['message' => 'No pending two-factor setup found.'], 400);
        }

        if (! $this->google2fa->verifyKey($user->two_factor_secret, $request->code)) {
            return response()->json(['message' => 'The verification code is invalid.'], 422);
        }

        $user->enableTwoFactor();
        $recoveryCodes = $user->generateTwoFactorRecoveryCodes();

        $deviceTrusted = false;
        if ($request->boolean('trust_device') && $request->device_id) {
            $user->trustDevice($request->device_id, $request->browser ?? 'Unknown browser', $request->ip());
            $deviceTrusted = true;
        }

        return response()->json([
            'message' => 'Two-factor authentication enabled.',
            'recovery_codes' => $recoveryCodes,
            'two_factor' => $user->getTwoFactorStatus(),
            'device_trusted' => $deviceTrusted,
        ]);
    }

    /**
     * Verify a 2FA code (TOTP or recovery code) during login.
     */
    public function verify(Request $request)
    {
        $request->validate([
            'code' => 'required|string',
            'trust_device' => 'nullable|boolean',
            'device_id' => 'nullable|string',
            'browser' => 'nullable|string',
        ]);

        $user = $request->user();

        if (! $user->hasTwoFactorEnabled()) {
            return response()->json(['message' => 'Two-factor authentication is not enabled.'], 400);
        }

        $code = $request->code;
        $isRecoveryCode = strlen($code) === 10;

        if ($isRecoveryCode) {
            $verified = $user->verifyRecoveryCode($code);
        } else {
            $verified = $this->google2fa->verifyKey($user->two_factor_secret, $code);
            if ($verified) {
                $user->updateTwoFactorVerificationTime();
            }
        }

        if (! $verified) {
            return response()->json(['message' => 'The verification code is invalid.'], 422);
        }

        if ($request->boolean('trust_device') && $request->device_id) {
            $user->trustDevice($request->device_id, $request->browser ?? 'Unknown browser', $request->ip());
        }

        return response()->json([
            'message' => 'Verification successful.',
            'verified' => true,
            'recovery_code_used' => $isRecoveryCode,
            'recovery_codes_remaining' => $isRecoveryCode ? $user->getRecoveryCodesCount() : null,
        ]);
    }

    /**
     * Check whether the current device is trusted (to skip the 2FA prompt).
     */
    public function checkDevice(Request $request)
    {
        $request->validate(['device_id' => 'required|string']);

        $user = $request->user();

        if (! $user->hasTwoFactorEnabled()) {
            return response()->json(['requires_2fa' => false, 'trusted' => false]);
        }

        $needsReverification = $user->needsTwoFactorReVerification();

        return response()->json([
            'requires_2fa' => true,
            'trusted' => $user->isDeviceTrusted($request->device_id) && ! $needsReverification,
            'needs_reverification' => $needsReverification,
        ]);
    }

    /**
     * Disable 2FA. Requires the account password and a valid code.
     */
    public function disable(Request $request)
    {
        $request->validate([
            'password' => 'required|string',
            'code' => 'required|string',
        ]);

        $user = $request->user();

        if (! Hash::check($request->password, $user->password)) {
            return response()->json(['message' => 'The provided password is incorrect.'], 422);
        }

        if (! $user->hasTwoFactorEnabled()) {
            return response()->json(['message' => 'Two-factor authentication is not enabled.'], 400);
        }

        $code = $request->code;
        $isRecoveryCode = strlen($code) === 10;

        if ($isRecoveryCode) {
            $codes = $user->two_factor_recovery_codes ?? [];
            $verified = in_array(strtoupper(trim($code)), $codes, true);
        } else {
            $verified = $this->google2fa->verifyKey($user->two_factor_secret, $code);
        }

        if (! $verified) {
            return response()->json(['message' => 'The verification code is invalid.'], 422);
        }

        $user->disableTwoFactor();

        return response()->json([
            'message' => 'Two-factor authentication disabled.',
            'two_factor' => $user->getTwoFactorStatus(),
        ]);
    }

    /**
     * Regenerate recovery codes. Requires the account password.
     */
    public function regenerateRecoveryCodes(Request $request)
    {
        $request->validate(['password' => 'required|string']);

        $user = $request->user();

        if (! Hash::check($request->password, $user->password)) {
            return response()->json(['message' => 'The provided password is incorrect.'], 422);
        }

        if (! $user->hasTwoFactorEnabled()) {
            return response()->json(['message' => 'Two-factor authentication is not enabled.'], 400);
        }

        return response()->json([
            'message' => 'Recovery codes regenerated.',
            'recovery_codes' => $user->generateTwoFactorRecoveryCodes(),
        ]);
    }

    /**
     * List trusted devices.
     */
    public function trustedDevices(Request $request)
    {
        return response()->json([
            'trusted_devices' => $request->user()->getTrustedDevices(),
        ]);
    }

    /**
     * Remove a single trusted device.
     */
    public function removeTrustedDevice(Request $request, string $deviceId)
    {
        $user = $request->user();
        $user->removeTrustedDevice($deviceId);

        return response()->json([
            'message' => 'Trusted device removed.',
            'trusted_devices' => $user->getTrustedDevices(),
        ]);
    }

    /**
     * Remove all trusted devices.
     */
    public function removeAllTrustedDevices(Request $request)
    {
        $request->user()->removeAllTrustedDevices();

        return response()->json(['message' => 'All trusted devices removed.']);
    }

    /**
     * Cancel a pending (unconfirmed) 2FA setup.
     */
    public function cancelSetup(Request $request)
    {
        $user = $request->user();

        if (! $user->isTwoFactorPending()) {
            return response()->json(['message' => 'No pending two-factor setup found.'], 400);
        }

        $user->two_factor_secret = null;
        $user->save();

        return response()->json([
            'message' => 'Two-factor setup cancelled.',
            'two_factor' => $user->getTwoFactorStatus(),
        ]);
    }
}
