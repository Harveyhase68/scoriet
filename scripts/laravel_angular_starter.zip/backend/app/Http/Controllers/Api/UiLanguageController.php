<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\UiLanguage;

class UiLanguageController extends Controller
{
    /**
     * Public list of active UI languages, used to populate the language
     * switcher before and after login.
     */
    public function active()
    {
        return response()->json([
            'languages' => UiLanguage::active()->ordered()->get(),
        ]);
    }
}
