<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\{:filesingularpascalcase:};
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;

class {:filesingularpascalcase:}Controller extends Controller
{
    public function index(Request $request)
    {
        ${:filecamelcase:} = $this->filtered($request)->get();

        return response()->json([
            '{:filename:}' => ${:filecamelcase:},
        ]);
    }

    public function show({:filesingularpascalcase:} ${:filesingularcamelcase:})
    {
        return response()->json([
            '{:filesingular:}' => ${:filesingularcamelcase:}->load($this->withRelations()),
        ]);
    }

    public function store(Request $request)
    {
        $validated = $this->validated($request);
        ${:filesingularcamelcase:} = {:filesingularpascalcase:}::create($validated);

        return response()->json([
            'message' => '{:filecaption:} created.',
            '{:filesingular:}' => ${:filesingularcamelcase:}->load($this->withRelations()),
        ], 201);
    }

    public function update(Request $request, {:filesingularpascalcase:} ${:filesingularcamelcase:})
    {
        $validated = $this->validated($request);
        ${:filesingularcamelcase:}->update($validated);

        return response()->json([
            'message' => '{:filecaption:} updated.',
            '{:filesingular:}' => ${:filesingularcamelcase:}->load($this->withRelations()),
        ]);
    }

    public function destroy({:filesingularpascalcase:} ${:filesingularcamelcase:})
    {
        ${:filesingularcamelcase:}->delete();

        return response()->json([
            'message' => '{:filecaption:} deleted.',
        ]);
    }

    /**
     * Print report for a single {:filesingular:}.
     */
    public function report({:filesingularpascalcase:} ${:filesingularcamelcase:})
    {
        $pdf = Pdf::loadView('reports.{:filesingular:}', ['{:filesingular:}' => ${:filesingularcamelcase:}->load($this->withRelations())]);

        return $pdf->stream('{:filesingular:}-' . ${:filesingularcamelcase:}->{:fileprimarykey:} . '.pdf');
    }

    /**
     * Print report for the whole (optionally filtered) {:filename:} list.
     */
    public function reportList(Request $request)
    {
        ${:filecamelcase:} = $this->filtered($request)->get();

        $pdf = Pdf::loadView('reports.{:filesingular:}-list', ['{:filename:}' => ${:filecamelcase:}])->setPaper('a4', 'landscape');

        return $pdf->stream('{:filename:}.pdf');
    }

    /**
     * @return array<int, string>
     */
    private function withRelations(): array
    {
        return [
{:for nmaxforeignkeysunique:}
            '{:foreignunique.referencedtablecamelcase:}',
{:endfor:}
        ];
    }

    private function filtered(Request $request)
    {
        $query = {:filesingularpascalcase:}::with($this->withRelations());

        if ($search = trim((string) $request->query('search', ''))) {
            $query->where(function ($q) use ($search) {
{:for nmaxsearchkeys:}
                $q->orWhere('{:keys.name:}', 'like', "%{$search}%");
{:endfor:}
            });
        }

        return $query;
    }

    /**
     * @return array<string, mixed>
     */
    private function validated(Request $request): array
    {
        return $request->validate([
{:for nmaxitemsnokey:}
            '{:item.name:}' => ['{:if item.notnull:}required{:else:}nullable{:endif:}', '{:item.laraveltype:}'{:if item.laraveltype eq 'string' && item.size > 0:}, 'max:{:item.size:}'{:endif:}],
{:endfor:}
        ]);
    }
}
