<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class {:filesingularpascalcase:} extends Model
{
    protected $table = '{:filename:}';

    protected $primaryKey = '{:fileprimarykey:}';

    public $timestamps = false;

    protected $fillable = [
{:for nmaxitemsnokey:}
        '{:item.name:}',
{:endfor:}
    ];

    protected function casts(): array
    {
        return [
{:for nmaxitems:}
{:switch item.laraveltype:}
{:case 'integer':}
            '{:item.name:}' => 'integer',
{:case 'boolean':}
            '{:item.name:}' => 'boolean',
{:case 'decimal':}
            '{:item.name:}' => 'decimal:2',
{:case 'datetime':}
            '{:item.name:}' => 'datetime',
{:case 'date':}
            '{:item.name:}' => 'date',
{:endswitch:}
{:endfor:}
        ];
    }
{:for nmaxforeignkeys:}

    public function {:foreign.referencedtablecamelcase:}(): BelongsTo
    {
        return $this->belongsTo({:foreign.referencedtablepascalcase:}::class, '{:foreign.name:}', '{:foreign.referencedcolumn:}');
    }
{:endfor:}
}
