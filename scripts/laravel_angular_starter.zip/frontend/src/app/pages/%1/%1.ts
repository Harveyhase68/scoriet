import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { ApiService } from '../../core/api/api.service';
{:for nmaxforeignkeysunique:}
import { {:foreignunique.referencedtablepascalcase:}Modal } from '../{:foreignunique.referencedtable:}/{:foreignunique.referencedtable:}-modal';
{:endfor:}
import { extractError } from '../../core/auth/http-error';
import { I18nService } from '../../core/i18n/i18n.service';
import { TranslatePipe } from '../../core/i18n/translate.pipe';

type View = 'list' | 'form';

interface {:filesingularpascalcase:} {
{:for nmaxitems:}
  {:item.name:}: {:if item.phptype eq 'int':}number{:elseif item.phptype eq 'float':}number{:elseif item.phptype eq 'bool':}boolean{:else:}string{:endif:} | null;
{:endfor:}
{:for nmaxforeignkeysunique:}
  {:foreignunique.referencedtablecamelcase:}?: any;
{:endfor:}
}

/**
 * {:filecaption:} master-detail page: a grid (master) and a form (detail)
 * swapped in place within the same panel, plus print reports for a single
 * record and for the whole list.
 */
@Component({
  selector: 'app-{:filename:}',
  imports: [CommonModule, ReactiveFormsModule, TranslatePipe{:for nmaxforeignkeysunique:}, {:foreignunique.referencedtablepascalcase:}Modal{:endfor:}],
  templateUrl: './{:filename:}.html',
})
export class {:filepascalcase:} {
  private fb = inject(FormBuilder);
  private api = inject(ApiService);
  private i18n = inject(I18nService);

  view = signal<View>('list');
  {:filecamelcase:} = signal<{:filesingularpascalcase:}[]>([]);
{:for nmaxforeignkeysunique:}
  {:foreignunique.referencedtablecamelcase:}Options = signal<any[]>([]);
  {:foreignunique.referencedtablecamelcase:}ModalOpen = signal(false);
{:endfor:}
  search = signal('');
  loading = signal(false);
  saving = signal(false);
  error = signal<string | null>(null);
  printingId = signal<number | null>(null);
  printingList = signal(false);

  editingId = signal<number | null>(null);

  form = this.fb.nonNullable.group({
{:for nmaxitemsnokey:}
{:if item.istimestamp:}
{:elseif item.phptype eq 'bool':}
    {:item.name:}: [false],
{:elseif item.isforeign:}
    {:item.name:}: [''],
{:else:}
    {:item.name:}: [''{:if item.notnull:}, Validators.required{:endif:}],
{:endif:}
{:endfor:}
  });

  constructor() {
{:for nmaxforeignkeysunique:}
    this.load{:foreignunique.referencedtablepascalcase:}();
{:endfor:}
    this.load{:filepascalcase:}();
  }

  // ------------------------------------------------------------- loading

  load{:filepascalcase:}(): void {
    this.loading.set(true);
    this.error.set(null);
    this.api.list{:filepascalcase:}(this.search()).subscribe({
      next: (res) => {
        this.loading.set(false);
        this.{:filecamelcase:}.set(res.{:filename:});
      },
      error: (err: HttpErrorResponse) => {
        this.loading.set(false);
        this.error.set(extractError(err));
      },
    });
  }
{:for nmaxforeignkeysunique:}

  load{:foreignunique.referencedtablepascalcase:}(): void {
    this.api.list{:foreignunique.referencedtablepascalcase:}().subscribe({
      next: (res) => this.{:foreignunique.referencedtablecamelcase:}Options.set(res.{:foreignunique.referencedtable:}),
    });
  }
{:endfor:}

  runSearch(term: string): void {
    this.search.set(term);
    this.load{:filepascalcase:}();
  }

  // ------------------------------------------------------------ list/form

  startCreate(): void {
    this.editingId.set(null);
    this.error.set(null);
    this.form.reset({
{:for nmaxitemsnokey:}
{:if item.istimestamp:}
{:elseif item.phptype eq 'bool':}
      {:item.name:}: false,
{:else:}
      {:item.name:}: '',
{:endif:}
{:endfor:}
    });
    this.view.set('form');
  }

  startEdit(record: any): void {
    this.editingId.set(record.{:fileprimarykey:});
    this.error.set(null);
    this.form.reset({
{:for nmaxitemsnokey:}
{:if item.istimestamp:}
{:elseif item.phptype eq 'bool':}
      {:item.name:}: record.{:item.name:} ?? false,
{:elseif item.isforeign:}
      {:item.name:}: record.{:item.name:} != null ? String(record.{:item.name:}) : '',
{:else:}
      {:item.name:}: record.{:item.name:} ?? '',
{:endif:}
{:endfor:}
    });
    this.view.set('form');
  }

  cancelForm(): void {
    this.view.set('list');
  }

  save(): void {
    if (this.form.invalid) return;
    this.saving.set(true);
    this.error.set(null);

    const raw = this.form.getRawValue();
    const payload: Record<string, unknown> = { ...raw };
{:for nmaxitemsnokey:}
{:if item.isforeign:}
    payload['{:item.name:}'] = raw.{:item.name:} ? Number(raw.{:item.name:}) : null;
{:endif:}
{:endfor:}

    const editingId = this.editingId();
    const request = editingId
      ? this.api.update{:filepascalcase:}(editingId, payload)
      : this.api.create{:filepascalcase:}(payload);

    request.subscribe({
      next: () => {
        this.saving.set(false);
        this.view.set('list');
        this.load{:filepascalcase:}();
      },
      error: (err: HttpErrorResponse) => {
        this.saving.set(false);
        this.error.set(extractError(err));
      },
    });
  }

  remove(record: any): void {
    if (!confirm(this.i18n.t('common_delete_confirm'))) return;
    this.api.delete{:filepascalcase:}(record.{:fileprimarykey:}).subscribe({
      next: () => this.load{:filepascalcase:}(),
      error: (err: HttpErrorResponse) => this.error.set(extractError(err)),
    });
  }
{:for nmaxforeignkeysunique:}

  // ------------------------------------------------------- {:foreignunique.referencedtable:} quick-add

  on{:foreignunique.referencedtablepascalcase:}Created(record: any): void {
    this.{:foreignunique.referencedtablecamelcase:}Options.update((list) => [...list, record]);
    this.{:foreignunique.referencedtablecamelcase:}ModalOpen.set(false);
  }
{:endfor:}

  // -------------------------------------------------------------- reports

  print(record: any): void {
    this.printingId.set(record.{:fileprimarykey:});
    this.api.report{:filepascalcase:}(record.{:fileprimarykey:}).subscribe({
      next: (blob) => {
        this.printingId.set(null);
        this.openPdf(blob);
      },
      error: (err: HttpErrorResponse) => {
        this.printingId.set(null);
        this.error.set(extractError(err));
      },
    });
  }

  printList(): void {
    this.printingList.set(true);
    this.api.report{:filepascalcase:}List(this.search()).subscribe({
      next: (blob) => {
        this.printingList.set(false);
        this.openPdf(blob);
      },
      error: (err: HttpErrorResponse) => {
        this.printingList.set(false);
        this.error.set(extractError(err));
      },
    });
  }

  private openPdf(blob: Blob): void {
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
  }
}
