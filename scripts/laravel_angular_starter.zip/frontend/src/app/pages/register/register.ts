import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthService } from '../../core/auth/auth.service';
import { extractError } from '../../core/auth/http-error';
import { I18nService } from '../../core/i18n/i18n.service';
import { TranslatePipe } from '../../core/i18n/translate.pipe';

@Component({
  selector: 'app-register',
  imports: [CommonModule, ReactiveFormsModule, RouterLink, TranslatePipe],
  template: `
    <div class="auth-shell">
      <div class="card">
        <h1>{{ 'register_title' | t }}</h1>
        <p class="subtitle">{{ 'register_subtitle' | t }}</p>

        @if (error()) { <div class="alert alert--error">{{ error() }}</div> }
        @if (success()) { <div class="alert alert--success">{{ success() }}</div> }

        <form [formGroup]="form" (ngSubmit)="submit()">
          <div class="field">
            <label for="register-name">{{ 'register_name' | t }}</label>
            <input id="register-name" type="text" formControlName="name" autocomplete="name" />
          </div>
          <div class="field">
            <label for="register-email">{{ 'register_email' | t }}</label>
            <input id="register-email" type="email" formControlName="email" autocomplete="email" />
          </div>
          <div class="field">
            <label for="register-password">{{ 'register_password' | t }}</label>
            <input id="register-password" type="password" formControlName="password" autocomplete="new-password" />
          </div>
          <div class="field">
            <label for="register-password-confirmation">{{ 'register_confirm_password' | t }}</label>
            <input id="register-password-confirmation" type="password" formControlName="password_confirmation" autocomplete="new-password" />
          </div>
          <button class="btn" type="submit" [disabled]="loading() || form.invalid">
            {{ loading() ? ('register_creating' | t) : ('register_submit' | t) }}
          </button>
        </form>

        <div class="links">
          {{ 'register_have_account' | t }} <a routerLink="/login">{{ 'register_signin' | t }}</a>
        </div>
      </div>
    </div>
  `,
})
export class Register {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private i18n = inject(I18nService);
  private router = inject(Router);

  loading = signal(false);
  error = signal<string | null>(null);
  success = signal<string | null>(null);

  form = this.fb.nonNullable.group({
    name: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(8)]],
    password_confirmation: ['', Validators.required],
  });

  submit(): void {
    if (this.form.invalid) return;
    this.loading.set(true);
    this.error.set(null);
    this.success.set(null);

    this.auth.register(this.form.getRawValue()).subscribe({
      next: () => {
        this.success.set(this.i18n.t('register_success'));
        setTimeout(() => this.router.navigate(['/login']), 1200);
      },
      error: (err: HttpErrorResponse) => {
        this.loading.set(false);
        this.error.set(extractError(err));
      },
    });
  }
}
