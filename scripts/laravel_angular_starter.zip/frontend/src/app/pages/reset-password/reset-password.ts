import { Component, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthService } from '../../core/auth/auth.service';
import { extractError } from '../../core/auth/http-error';
import { I18nService } from '../../core/i18n/i18n.service';
import { TranslatePipe } from '../../core/i18n/translate.pipe';

@Component({
  selector: 'app-reset-password',
  imports: [CommonModule, ReactiveFormsModule, RouterLink, TranslatePipe],
  template: `
    <div class="auth-shell">
      <div class="card">
        <h1>{{ 'reset_title' | t }}</h1>
        <p class="subtitle">for {{ form.getRawValue().email || ('reset_subtitle_fallback' | t) }}</p>

        @if (error()) { <div class="alert alert--error">{{ error() }}</div> }
        @if (success()) { <div class="alert alert--success">{{ success() }}</div> }

        <form [formGroup]="form" (ngSubmit)="submit()">
          <div class="field">
            <label for="reset-email">{{ 'reset_email' | t }}</label>
            <input id="reset-email" type="email" formControlName="email" autocomplete="email" />
          </div>
          <div class="field">
            <label for="reset-password">{{ 'reset_new_password' | t }}</label>
            <input id="reset-password" type="password" formControlName="password" autocomplete="new-password" />
          </div>
          <div class="field">
            <label for="reset-password-confirmation">{{ 'reset_confirm_password' | t }}</label>
            <input id="reset-password-confirmation" type="password" formControlName="password_confirmation" autocomplete="new-password" />
          </div>
          <button class="btn" type="submit" [disabled]="loading() || form.invalid">
            {{ loading() ? ('reset_resetting' | t) : ('reset_submit' | t) }}
          </button>
        </form>

        <div class="links"><a routerLink="/login">{{ 'reset_back' | t }}</a></div>
      </div>
    </div>
  `,
})
export class ResetPassword implements OnInit {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private i18n = inject(I18nService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  loading = signal(false);
  error = signal<string | null>(null);
  success = signal<string | null>(null);

  form = this.fb.nonNullable.group({
    token: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(8)]],
    password_confirmation: ['', Validators.required],
  });

  ngOnInit(): void {
    const { token, email } = this.route.snapshot.queryParams;
    this.form.patchValue({ token: token ?? '', email: email ?? '' });
  }

  submit(): void {
    if (this.form.invalid) return;
    this.loading.set(true);
    this.error.set(null);
    this.success.set(null);

    this.auth.resetPassword(this.form.getRawValue()).subscribe({
      next: (res) => {
        this.success.set(res.message + this.i18n.t('reset_redirecting'));
        setTimeout(() => this.router.navigate(['/login']), 1400);
      },
      error: (err: HttpErrorResponse) => {
        this.loading.set(false);
        this.error.set(extractError(err));
      },
    });
  }
}
