import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { AuthService } from '../auth/auth.service';
import { Language } from './i18n.models';
import { en } from './locales/en';
import { de } from './locales/de';

export type TranslationKey = keyof typeof en;

const DICTIONARIES: Record<string, Record<TranslationKey, string>> = { en, de };
const STORAGE_KEY = 'las_language';

/**
 * Client-side UI translation: flat per-locale dictionaries (see locales/),
 * switched at runtime and persisted per-user via the backend `language`
 * column. Backend-generated strings (validation errors) are not covered —
 * only the Angular UI text is translated this way.
 */
@Injectable({ providedIn: 'root' })
export class I18nService {
  private http = inject(HttpClient);
  private auth = inject(AuthService);
  private api = environment.apiUrl;

  readonly language = signal<string>(this.detectInitialLanguage());
  readonly availableLanguages = signal<Language[]>([]);

  /** Whether the browser already had an explicit choice before this session — see syncFromUser(). */
  private readonly hadStoredPreference = !!localStorage.getItem(STORAGE_KEY);

  constructor() {
    this.loadActiveLanguages();
  }

  private detectInitialLanguage(): string {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored && DICTIONARIES[stored]) return stored;

    const browser = navigator.language.slice(0, 2);
    return DICTIONARIES[browser] ? browser : 'en';
  }

  loadActiveLanguages(): void {
    this.http.get<{ languages: Language[] }>(`${this.api}/api/ui-languages/active`).subscribe({
      next: (res) => this.availableLanguages.set(res.languages),
      error: () => undefined,
    });
  }

  /**
   * Reconciles the account's saved language with the browser (called after
   * login / on refresh). If the browser had no explicit choice yet, the
   * account's preference wins; otherwise the browser's active choice wins
   * and is pushed to the account, so a language picked on the login screen
   * isn't silently discarded by an older saved preference.
   */
  syncFromUser(languageCode: string | null | undefined): void {
    if (!languageCode || !DICTIONARIES[languageCode]) return;

    if (!this.hadStoredPreference) {
      this.setLanguage(languageCode, false);
    } else if (languageCode !== this.language()) {
      this.setLanguage(this.language(), true);
    }
  }

  setLanguage(code: string, persist = true): void {
    if (!DICTIONARIES[code]) return;
    this.language.set(code);
    localStorage.setItem(STORAGE_KEY, code);

    if (persist && this.auth.hasToken()) {
      this.http.put(`${this.api}/api/profile/language`, { language: code }).subscribe({ error: () => undefined });
    }
  }

  /** `key` is typically a `TranslationKey`, but plain `string` is accepted too for dynamically-built keys (e.g. `'customers_status_' + status`). */
  t(key: TranslationKey | (string & {}), params?: Record<string, string | number>): string {
    const dict = DICTIONARIES[this.language()] ?? en;
    let text = dict[key as TranslationKey] ?? en[key as TranslationKey] ?? key;

    if (params) {
      for (const [name, value] of Object.entries(params)) {
        text = text.replace(`{${name}}`, String(value));
      }
    }

    return text;
  }
}
