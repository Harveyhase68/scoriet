import { Component, inject } from '@angular/core';
import { I18nService } from './i18n.service';

/** Small language dropdown, reused in the app shell sidebar and on the auth pages. */
@Component({
  selector: 'app-language-selector',
  template: `
    <select
      class="language-selector"
      (change)="i18n.setLanguage($any($event.target).value)"
      aria-label="Language"
    >
      @for (lang of i18n.availableLanguages(); track lang.code) {
        <option [value]="lang.code" [selected]="lang.code === i18n.language()">{{ lang.flag }} {{ lang.native_name }}</option>
      }
    </select>
  `,
})
export class LanguageSelector {
  i18n = inject(I18nService);
}
