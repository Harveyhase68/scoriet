import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../auth/auth.service';
import { I18nService } from '../i18n/i18n.service';
import { TranslatePipe } from '../i18n/translate.pipe';
import { LanguageSelector } from '../i18n/language-selector';

/**
 * Application shell: a fixed left sidebar with the main menu and a flat
 * content area on the right where individual pages are swapped via the
 * router outlet.
 *
 * Nav entries are generated per active schema table: if the table has a
 * FormSet/main-menu configured in Scoriet, its display name is used;
 * otherwise a generic fallback entry (the table's own caption) is shown, so
 * every non-excluded table is always reachable even without menu setup.
 */
@Component({
  selector: 'app-shell',
  imports: [RouterLink, RouterLinkActive, RouterOutlet, TranslatePipe, LanguageSelector],
  template: `
    <div class="shell">
      <aside class="sidebar">
        <div class="sidebar__brand">{:projectcaption:}</div>

        <nav class="sidebar__nav">
          <a routerLink="/dashboard" routerLinkActive="active">{{ 'nav_dashboard' | t }}</a>
{:for nmaxtables:}
{:if form_set_name ne '':}
          <a routerLink="/{:filename:}" routerLinkActive="active">{:formmenu.display_name:}</a>
{:else:}
          <a routerLink="/{:filename:}" routerLinkActive="active">{:filecaption:}</a>
{:endif:}
{:endfor:}
          <a routerLink="/profile" routerLinkActive="active">{{ 'nav_profile' | t }}</a>
        </nav>

        <div class="sidebar__footer">
          @if (auth.user(); as user) {
            <div class="sidebar__user">{{ user.name }}</div>
          }
          <app-language-selector />
          <button class="btn btn--ghost btn--auto" (click)="logout()">{{ 'nav_logout' | t }}</button>
        </div>
      </aside>

      <main class="content">
        <router-outlet />
      </main>
    </div>
  `,
})
export class Shell {
  auth = inject(AuthService);
  private i18n = inject(I18nService);
  private router = inject(Router);

  constructor() {
    this.i18n.syncFromUser(this.auth.user()?.language);
  }

  logout(): void {
    this.auth.logout().subscribe(() => this.router.navigate(['/login']));
  }
}
