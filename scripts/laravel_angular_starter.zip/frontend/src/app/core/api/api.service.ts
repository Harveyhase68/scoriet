import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private http = inject(HttpClient);
  private api = environment.apiUrl;
{:for nmaxtables:}

  // ----------------------------------------------------------- {:filename:}

  list{:filepascalcase:}(search = ''): Observable<{ {:filename:}: any[] }> {
    const params = new HttpParams({ fromObject: search ? { search } : {} });
    return this.http.get<{ {:filename:}: any[] }>(`${this.api}/api/{:filename:}`, { params });
  }

  get{:filepascalcase:}(id: number): Observable<{ {:filesingular:}: any }> {
    return this.http.get<{ {:filesingular:}: any }>(`${this.api}/api/{:filename:}/${id}`);
  }

  create{:filepascalcase:}(payload: Record<string, unknown>): Observable<{ {:filesingular:}: any }> {
    return this.http.post<{ {:filesingular:}: any }>(`${this.api}/api/{:filename:}`, payload);
  }

  update{:filepascalcase:}(id: number, payload: Record<string, unknown>): Observable<{ {:filesingular:}: any }> {
    return this.http.put<{ {:filesingular:}: any }>(`${this.api}/api/{:filename:}/${id}`, payload);
  }

  delete{:filepascalcase:}(id: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.api}/api/{:filename:}/${id}`);
  }

  /** Fetches the single-record PDF report as a blob (auth header is attached by the interceptor). */
  report{:filepascalcase:}(id: number): Observable<Blob> {
    return this.http.get(`${this.api}/api/{:filename:}/${id}/report`, { responseType: 'blob' });
  }

  /** Fetches the whole (optionally filtered) list as a PDF blob. */
  report{:filepascalcase:}List(search = ''): Observable<Blob> {
    const params = new HttpParams({ fromObject: search ? { search } : {} });
    return this.http.get(`${this.api}/api/{:filename:}/report`, { params, responseType: 'blob' });
  }
{:endfor:}
}
