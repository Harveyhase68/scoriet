import { HttpErrorResponse } from '@angular/common/http';

/**
 * Turn a Laravel JSON error response into a single human-readable string.
 * Prefers the first field validation error, then the top-level message.
 */
export function extractError(err: HttpErrorResponse): string {
  const body = err.error;

  if (body?.errors && typeof body.errors === 'object') {
    const first = Object.values(body.errors)[0];
    if (Array.isArray(first) && first.length) {
      return String(first[0]);
    }
  }

  if (body?.message) {
    return String(body.message);
  }

  if (err.status === 0) {
    return 'Cannot reach the server. Is the backend running?';
  }

  return 'Something went wrong. Please try again.';
}
