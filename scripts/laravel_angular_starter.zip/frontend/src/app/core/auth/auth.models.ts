export interface TwoFactorStatus {
  enabled: boolean;
  pending: boolean;
  recovery_codes_count: number;
  trusted_devices_count: number;
  needs_reverification: boolean;
  confirmed_at: string | null;
  last_verified_at: string | null;
}

export interface User {
  id: number;
  name: string;
  email: string;
  avatar_url: string | null;
  language: string;
  email_verified_at: string | null;
  created_at: string | null;
  two_factor: TwoFactorStatus;
}

export interface TokenResponse {
  token_type: string;
  expires_in: number;
  access_token: string;
  refresh_token: string;
}

export interface TrustedDevice {
  device_id: string;
  browser: string;
  ip: string;
  trusted_until: string;
  created_at: string;
}

export interface TwoFactorEnableResponse {
  message: string;
  secret: string;
  qr_code_svg: string;
  qr_code_url: string;
}

export interface TwoFactorConfirmResponse {
  message: string;
  recovery_codes: string[];
  two_factor: TwoFactorStatus;
  device_trusted: boolean;
}
