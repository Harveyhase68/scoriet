import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { map, catchError, of } from 'rxjs';
import { AuthService } from './auth.service';

/**
 * Protects routes that require authentication. If the user object is already
 * loaded we allow immediately; otherwise, when a token exists, we try to load
 * the user (covers a page refresh). No token → redirect to /login.
 */
export const authGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.isAuthenticated()) {
    return true;
  }

  if (auth.hasToken()) {
    return auth.loadUser().pipe(
      map(() => true),
      catchError(() => {
        auth.clearSession();
        return of(router.createUrlTree(['/login']));
      }),
    );
  }

  return router.createUrlTree(['/login']);
};

/** Keeps authenticated users away from guest-only pages (login/register). */
export const guestGuard: CanActivateFn = () => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (auth.hasToken()) {
    return router.createUrlTree(['/dashboard']);
  }
  return true;
};
