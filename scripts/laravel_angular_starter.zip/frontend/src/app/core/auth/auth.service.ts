import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap, switchMap, of } from 'rxjs';
import { environment } from '../../../environments/environment';
import {
  User,
  TokenResponse,
  TwoFactorStatus,
  TwoFactorEnableResponse,
  TwoFactorConfirmResponse,
  TrustedDevice,
} from './auth.models';

const ACCESS_TOKEN_KEY = 'las_access_token';
const REFRESH_TOKEN_KEY = 'las_refresh_token';
const DEVICE_ID_KEY = 'las_device_id';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private api = environment.apiUrl;

  /** Reactive current user. `null` = not loaded / logged out. */
  readonly user = signal<User | null>(null);
  readonly isAuthenticated = computed(() => this.user() !== null);

  // ---------------------------------------------------------------- tokens

  get accessToken(): string | null {
    return localStorage.getItem(ACCESS_TOKEN_KEY);
  }

  private storeTokens(res: TokenResponse): void {
    localStorage.setItem(ACCESS_TOKEN_KEY, res.access_token);
    localStorage.setItem(REFRESH_TOKEN_KEY, res.refresh_token);
  }

  private clearTokens(): void {
    localStorage.removeItem(ACCESS_TOKEN_KEY);
    localStorage.removeItem(REFRESH_TOKEN_KEY);
  }

  hasToken(): boolean {
    return !!this.accessToken;
  }

  /** Stable per-browser id used for the "trust this device" 2FA feature. */
  get deviceId(): string {
    let id = localStorage.getItem(DEVICE_ID_KEY);
    if (!id) {
      id = crypto.randomUUID();
      localStorage.setItem(DEVICE_ID_KEY, id);
    }
    return id;
  }

  // ------------------------------------------------------------- auth flow

  /** Log in via the OAuth2 password grant, then load the user profile. */
  login(email: string, password: string): Observable<User> {
    return this.http
      .post<TokenResponse>(`${this.api}/oauth/token`, {
        grant_type: 'password',
        client_id: environment.oauth.clientId,
        client_secret: environment.oauth.clientSecret,
        username: email,
        password,
        scope: '',
      })
      .pipe(
        tap((res) => this.storeTokens(res)),
        switchMap(() => this.loadUser()),
      );
  }

  register(payload: {
    name: string;
    email: string;
    password: string;
    password_confirmation: string;
  }): Observable<{ message: string; user: User }> {
    return this.http.post<{ message: string; user: User }>(
      `${this.api}/api/auth/register`,
      payload,
    );
  }

  /** Fetch the authenticated user and cache it in the `user` signal. */
  loadUser(): Observable<User> {
    return this.http
      .get<{ user: User }>(`${this.api}/api/auth/me`)
      .pipe(
        tap((res) => this.user.set(res.user)),
        switchMap((res) => of(res.user)),
      );
  }

  logout(): Observable<unknown> {
    const done = () => {
      this.clearTokens();
      this.user.set(null);
    };
    return this.http.post(`${this.api}/api/auth/logout`, {}).pipe(
      tap({ next: done, error: done }),
    );
  }

  /** Local-only logout (used by the interceptor on 401). */
  clearSession(): void {
    this.clearTokens();
    this.user.set(null);
  }

  refreshToken(): Observable<TokenResponse> {
    return this.http
      .post<TokenResponse>(`${this.api}/oauth/token`, {
        grant_type: 'refresh_token',
        refresh_token: localStorage.getItem(REFRESH_TOKEN_KEY),
        client_id: environment.oauth.clientId,
        client_secret: environment.oauth.clientSecret,
        scope: '',
      })
      .pipe(tap((res) => this.storeTokens(res)));
  }

  // -------------------------------------------------- password reset flow

  forgotPassword(email: string): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(
      `${this.api}/api/auth/forgot-password`,
      { email },
    );
  }

  resetPassword(payload: {
    token: string;
    email: string;
    password: string;
    password_confirmation: string;
  }): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(
      `${this.api}/api/auth/reset-password`,
      payload,
    );
  }

  // ------------------------------------------------------------- profile

  updateProfile(payload: { name: string; email: string }): Observable<{ user: User }> {
    return this.http
      .put<{ user: User }>(`${this.api}/api/profile`, payload)
      .pipe(tap((res) => this.user.set(res.user)));
  }

  updatePassword(payload: {
    current_password: string;
    password: string;
    password_confirmation: string;
  }): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(`${this.api}/api/profile/password`, payload);
  }

  uploadAvatar(file: File): Observable<{ message: string; avatar_url: string }> {
    const form = new FormData();
    form.append('avatar', file);
    return this.http
      .post<{ message: string; avatar_url: string }>(`${this.api}/api/profile/avatar`, form)
      .pipe(
        tap((res) => {
          const u = this.user();
          if (u) this.user.set({ ...u, avatar_url: res.avatar_url });
        }),
      );
  }

  deleteAvatar(): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.api}/api/profile/avatar`).pipe(
      tap(() => {
        const u = this.user();
        if (u) this.user.set({ ...u, avatar_url: null });
      }),
    );
  }

  // ----------------------------------------------------------------- 2FA

  twoFactorStatus(): Observable<{ two_factor: TwoFactorStatus }> {
    return this.http.get<{ two_factor: TwoFactorStatus }>(`${this.api}/api/2fa/status`);
  }

  twoFactorEnable(password: string): Observable<TwoFactorEnableResponse> {
    return this.http.post<TwoFactorEnableResponse>(`${this.api}/api/2fa/enable`, { password });
  }

  twoFactorConfirm(code: string, trustDevice: boolean): Observable<TwoFactorConfirmResponse> {
    return this.http
      .post<TwoFactorConfirmResponse>(`${this.api}/api/2fa/confirm`, {
        code,
        trust_device: trustDevice,
        device_id: this.deviceId,
        browser: navigator.userAgent,
      })
      .pipe(tap((res) => this.patchTwoFactor(res.two_factor)));
  }

  twoFactorVerify(code: string, trustDevice: boolean): Observable<{ verified: boolean }> {
    return this.http.post<{ verified: boolean }>(`${this.api}/api/2fa/verify`, {
      code,
      trust_device: trustDevice,
      device_id: this.deviceId,
      browser: navigator.userAgent,
    });
  }

  twoFactorCheckDevice(): Observable<{ requires_2fa: boolean; trusted: boolean }> {
    return this.http.post<{ requires_2fa: boolean; trusted: boolean }>(
      `${this.api}/api/2fa/check-device`,
      { device_id: this.deviceId },
    );
  }

  twoFactorDisable(password: string, code: string): Observable<{ two_factor: TwoFactorStatus }> {
    return this.http
      .post<{ two_factor: TwoFactorStatus }>(`${this.api}/api/2fa/disable`, { password, code })
      .pipe(tap((res) => this.patchTwoFactor(res.two_factor)));
  }

  twoFactorRegenerateCodes(password: string): Observable<{ recovery_codes: string[] }> {
    return this.http.post<{ recovery_codes: string[] }>(`${this.api}/api/2fa/recovery-codes`, {
      password,
    });
  }

  trustedDevices(): Observable<{ trusted_devices: TrustedDevice[] }> {
    return this.http.get<{ trusted_devices: TrustedDevice[] }>(`${this.api}/api/2fa/trusted-devices`);
  }

  private patchTwoFactor(status: TwoFactorStatus): void {
    const u = this.user();
    if (u) this.user.set({ ...u, two_factor: status });
  }
}
