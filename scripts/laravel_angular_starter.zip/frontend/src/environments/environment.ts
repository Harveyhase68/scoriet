export const environment = {
  production: false,

  // Laravel backend base URL (no trailing slash).
  apiUrl: 'http://127.0.0.1:8000',

  // Passport password-grant client. For a first-party SPA using the password
  // grant these are shipped with the app by design; keep this client's scope
  // limited on the backend. Created via: php artisan passport:client --password
  oauth: {
    clientId: '019f5cb2-24da-73ca-b375-6a3e9f79b2cb',
    clientSecret: 'SBjIV9jWI7FZfgSWzyHlUNBHVBiQKx0tiqslH2yb',
  },
};
