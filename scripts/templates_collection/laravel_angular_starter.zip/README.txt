Template: laravel_angular_starter
Description: Laravel API backend + Angular SPA frontend starter: table CRUD, print/PDF reports, FK quick-add lookups, login with 2FA (Google2FA), and a menu that follows the configured FormSet or falls back to every active table.
Category: Web
Language: PHP
Creator: Scoriet System (office@scoriet.dev)
Created: 2026-07-20 16:48:24

Scoriet Template Export
https://scoriet.com
