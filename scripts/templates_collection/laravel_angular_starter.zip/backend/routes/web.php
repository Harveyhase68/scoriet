<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
| This backend is a pure JSON API consumed by the separately hosted Angular
| SPA (see frontend/), so there are no Blade/session-based web routes here.
| This just gives a friendly response when the API root is opened directly.
*/
Route::get('/', function () {
    return response()->json([
        'name' => config('app.name'),
        'status' => 'ok',
    ]);
});