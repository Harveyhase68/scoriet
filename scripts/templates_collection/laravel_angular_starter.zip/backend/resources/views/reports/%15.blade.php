<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{:filecaption:} {{ ${:filesingular:}->{:fileprimarykey:} }}</title>
    <style>
        body { font-family: sans-serif; font-size: 12px; color: #1b1f24; }
        h1 { font-size: 18px; margin: 0 0 4px; }
        .subtitle { color: #626b78; margin: 0 0 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 18px; }
        td, th { padding: 5px 8px; text-align: left; vertical-align: top; }
        .label { color: #626b78; width: 220px; }
    </style>
</head>
<body>
    <h1>{:filecaption:} #{{ ${:filesingular:}->{:fileprimarykey:} }}</h1>
    <p class="subtitle">generated {{ now()->format('Y-m-d H:i') }}</p>

    <table>
{:for nmaxitemsnokey:}
        <tr><td class="label">{:item.caption:}</td><td>{{ ${:filesingular:}->{:item.name:} ?? '—' }}</td></tr>
{:endfor:}
    </table>
</body>
</html>