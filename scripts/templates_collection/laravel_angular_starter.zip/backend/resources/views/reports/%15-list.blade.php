<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{:filecaption:}</title>
    <style>
        body { font-family: sans-serif; font-size: 11px; color: #1b1f24; }
        h1 { font-size: 18px; margin: 0 0 4px; }
        .subtitle { color: #626b78; margin: 0 0 16px; }
        table { width: 100%; border-collapse: collapse; }
        th { background: #f4f5f7; text-align: left; padding: 6px 8px; border-bottom: 2px solid #e2e5ea; }
        td { padding: 5px 8px; border-bottom: 1px solid #e2e5ea; }
    </style>
</head>
<body>
    <h1>{:filecaption:}</h1>
    <p class="subtitle">{{ count(${:filecamelcase:}) }} record(s) &middot; generated {{ now()->format('Y-m-d H:i') }}</p>

    <table>
        <thead>
            <tr>
{:for nmaxitemsnokeyall:}
                <th>{:item.caption:}</th>
{:endfor:}
            </tr>
        </thead>
        <tbody>
            @foreach (${:filecamelcase:} as ${:filesingular:})
                <tr>
{:for nmaxitemsnokeyall:}
                    <td>{{ ${:filesingular:}->{:item.name:} ?? '—' }}</td>
{:endfor:}
                </tr>
            @endforeach
        </tbody>
    </table>
</body>
</html>