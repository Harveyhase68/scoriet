<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rules\Password;
use Intervention\Image\Drivers\Gd\Driver as GdDriver;
use Intervention\Image\Format;
use Intervention\Image\ImageManager;

class ProfileController extends Controller
{
    /**
     * Update the authenticated user's name and email.
     */
    public function update(Request $request)
    {
        $user = $request->user();

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users,email,'.$user->id],
        ]);

        // Changing the email invalidates a previous verification.
        if ($validated['email'] !== $user->email) {
            $user->email_verified_at = null;
        }

        $user->name = $validated['name'];
        $user->email = $validated['email'];
        $user->save();

        return response()->json([
            'message' => 'Profile updated.',
            'user' => $this->userPayload($user),
        ]);
    }

    /**
     * Persist the authenticated user's preferred UI language.
     */
    public function updateLanguage(Request $request)
    {
        $user = $request->user();

        $validated = $request->validate([
            'language' => ['required', 'string', 'in:en,de'],
        ]);

        $user->language = $validated['language'];
        $user->save();

        return response()->json([
            'user' => $this->userPayload($user),
        ]);
    }

    /**
     * Change the authenticated user's password. Requires the current password.
     */
    public function updatePassword(Request $request)
    {
        $user = $request->user();

        $request->validate([
            'current_password' => ['required', 'string'],
            'password' => ['required', 'confirmed', Password::defaults()],
        ]);

        if (! Hash::check($request->current_password, $user->password)) {
            return response()->json([
                'message' => 'The current password is incorrect.',
                'errors' => ['current_password' => ['The current password is incorrect.']],
            ], 422);
        }

        $user->password = Hash::make($request->password);
        $user->save();

        return response()->json([
            'message' => 'Password changed.',
        ]);
    }

    /**
     * Upload / replace the avatar. Resized to a 256x256 square (cover fit).
     */
    public function uploadAvatar(Request $request)
    {
        $user = $request->user();

        $request->validate([
            'avatar' => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
        ]);

        // Remove previous avatar file if present.
        if ($user->avatar_path && Storage::disk('public')->exists($user->avatar_path)) {
            Storage::disk('public')->delete($user->avatar_path);
        }

        $manager = ImageManager::usingDriver(GdDriver::class);
        $image = $manager->decodePath($request->file('avatar')->getRealPath());
        $image->cover(256, 256);

        $path = 'avatars/'.$user->id.'_'.time().'.webp';
        Storage::disk('public')->put($path, (string) $image->encodeUsingFormat(Format::WEBP, quality: 85));

        $user->avatar_path = $path;
        $user->save();

        return response()->json([
            'message' => 'Avatar updated.',
            'avatar_url' => asset('storage/'.$path),
        ]);
    }

    /**
     * Remove the current avatar.
     */
    public function deleteAvatar(Request $request)
    {
        $user = $request->user();

        if ($user->avatar_path && Storage::disk('public')->exists($user->avatar_path)) {
            Storage::disk('public')->delete($user->avatar_path);
        }

        $user->avatar_path = null;
        $user->save();

        return response()->json([
            'message' => 'Avatar removed.',
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    private function userPayload($user): array
    {
        return [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'avatar_url' => $user->avatar_path ? asset('storage/'.$user->avatar_path) : null,
            'language' => $user->language,
            'email_verified_at' => $user->email_verified_at?->toISOString(),
            'created_at' => $user->created_at?->toISOString(),
            'two_factor' => $user->getTwoFactorStatus(),
        ];
    }
}