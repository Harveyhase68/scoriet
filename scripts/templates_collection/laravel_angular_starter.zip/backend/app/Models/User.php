<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Carbon\Carbon;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;

class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'avatar_path',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
        'two_factor_secret',
        'two_factor_recovery_codes',
        'two_factor_trusted_devices',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'two_factor_enabled' => 'boolean',
            'two_factor_confirmed_at' => 'datetime',
            'two_factor_last_verified_at' => 'datetime',
            'two_factor_recovery_codes' => 'array',
            'two_factor_trusted_devices' => 'array',
        ];
    }

    // ==================== TWO-FACTOR AUTHENTICATION ====================
    // Ported from scoriet (app/Models/User.php). Self-contained: depends only
    // on the two_factor_* columns and pragmarx/google2fa (used in the controller).

    /**
     * Check if 2FA is enabled and confirmed for this user.
     */
    public function hasTwoFactorEnabled(): bool
    {
        return $this->two_factor_enabled && $this->two_factor_confirmed_at !== null;
    }

    /**
     * Check if 2FA is in setup state (secret generated but not confirmed).
     */
    public function isTwoFactorPending(): bool
    {
        return $this->two_factor_secret !== null && ! $this->two_factor_enabled;
    }

    /**
     * Generate new recovery codes (8 codes, 10 characters each).
     *
     * @return array<int, string>
     */
    public function generateTwoFactorRecoveryCodes(): array
    {
        $codes = [];
        for ($i = 0; $i < 8; $i++) {
            $codes[] = strtoupper(bin2hex(random_bytes(5))); // 10 hex characters
        }

        $this->two_factor_recovery_codes = $codes;
        $this->save();

        return $codes;
    }

    /**
     * Get remaining recovery codes count.
     */
    public function getRecoveryCodesCount(): int
    {
        $codes = $this->two_factor_recovery_codes;

        return is_array($codes) ? count($codes) : 0;
    }

    /**
     * Verify and consume a recovery code.
     */
    public function verifyRecoveryCode(string $code): bool
    {
        $codes = $this->two_factor_recovery_codes;

        if (! is_array($codes)) {
            return false;
        }

        $normalizedCode = strtoupper(trim($code));
        $index = array_search($normalizedCode, $codes, true);

        if ($index !== false) {
            unset($codes[$index]);
            $this->two_factor_recovery_codes = array_values($codes);
            $this->two_factor_last_verified_at = now();
            $this->save();

            return true;
        }

        return false;
    }

    /**
     * Enable 2FA after successful verification.
     */
    public function enableTwoFactor(): void
    {
        $this->two_factor_enabled = true;
        $this->two_factor_confirmed_at = now();
        $this->two_factor_last_verified_at = now();
        $this->save();
    }

    /**
     * Disable 2FA and clear all related data.
     */
    public function disableTwoFactor(): void
    {
        $this->two_factor_secret = null;
        $this->two_factor_enabled = false;
        $this->two_factor_confirmed_at = null;
        $this->two_factor_recovery_codes = null;
        $this->two_factor_trusted_devices = null;
        $this->two_factor_last_verified_at = null;
        $this->save();
    }

    /**
     * Check if a device is trusted (and trust has not expired).
     */
    public function isDeviceTrusted(string $deviceId): bool
    {
        $devices = $this->two_factor_trusted_devices;

        if (! is_array($devices)) {
            return false;
        }

        foreach ($devices as $device) {
            if ($device['device_id'] === $deviceId) {
                $trustedUntil = Carbon::parse($device['trusted_until']);
                if ($trustedUntil->isFuture()) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Add a device to the trusted list (valid for 30 days).
     */
    public function trustDevice(string $deviceId, string $browser, string $ip): void
    {
        $devices = $this->two_factor_trusted_devices ?? [];

        // Remove existing entry for this device if it exists.
        $devices = array_filter($devices, fn ($d) => $d['device_id'] !== $deviceId);

        $devices[] = [
            'device_id' => $deviceId,
            'browser' => $browser,
            'ip' => $ip,
            'trusted_until' => now()->addDays(30)->toISOString(),
            'created_at' => now()->toISOString(),
        ];

        // Keep only the last 10 trusted devices.
        $devices = array_slice($devices, -10);

        $this->two_factor_trusted_devices = array_values($devices);
        $this->save();
    }

    /**
     * Remove a single trusted device.
     */
    public function removeTrustedDevice(string $deviceId): void
    {
        $devices = $this->two_factor_trusted_devices ?? [];
        $devices = array_filter($devices, fn ($d) => $d['device_id'] !== $deviceId);

        $this->two_factor_trusted_devices = array_values($devices);
        $this->save();
    }

    /**
     * Remove all trusted devices.
     */
    public function removeAllTrustedDevices(): void
    {
        $this->two_factor_trusted_devices = [];
        $this->save();
    }

    /**
     * Get the list of currently-valid trusted devices (prunes expired ones).
     *
     * @return array<int, array<string, mixed>>
     */
    public function getTrustedDevices(): array
    {
        $devices = $this->two_factor_trusted_devices ?? [];

        $validDevices = array_filter($devices, function ($device) {
            $trustedUntil = Carbon::parse($device['trusted_until']);

            return $trustedUntil->isFuture();
        });

        if (count($validDevices) !== count($devices)) {
            $this->two_factor_trusted_devices = array_values($validDevices);
            $this->save();
        }

        return array_values($validDevices);
    }

    /**
     * Check if the user needs to re-verify 2FA (every 30 days).
     */
    public function needsTwoFactorReVerification(): bool
    {
        if (! $this->hasTwoFactorEnabled()) {
            return false;
        }

        if (! $this->two_factor_last_verified_at) {
            return true;
        }

        return $this->two_factor_last_verified_at->addDays(30)->isPast();
    }

    /**
     * Update the last 2FA verification time to now.
     */
    public function updateTwoFactorVerificationTime(): void
    {
        $this->two_factor_last_verified_at = now();
        $this->save();
    }

    /**
     * Get the 2FA status summary for API responses.
     *
     * @return array<string, mixed>
     */
    public function getTwoFactorStatus(): array
    {
        return [
            'enabled' => $this->hasTwoFactorEnabled(),
            'pending' => $this->isTwoFactorPending(),
            'recovery_codes_count' => $this->getRecoveryCodesCount(),
            'trusted_devices_count' => count($this->getTrustedDevices()),
            'needs_reverification' => $this->needsTwoFactorReVerification(),
            'confirmed_at' => $this->two_factor_confirmed_at?->toISOString(),
            'last_verified_at' => $this->two_factor_last_verified_at?->toISOString(),
        ];
    }
}