import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from './auth.service';

/**
 * Attaches the Bearer access token to API requests and, on a 401, clears the
 * local session and redirects to the login page.
 *
 * The OAuth token endpoint is skipped so the client credentials in the login
 * body are never shadowed by a stale Bearer header.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  const isTokenEndpoint = req.url.includes('/oauth/token');
  const token = auth.accessToken;

  const authReq =
    token && !isTokenEndpoint
      ? req.clone({ setHeaders: { Authorization: `Bearer ${token}` } })
      : req;

  return next(authReq).pipe(
    catchError((error: HttpErrorResponse) => {
      if (error.status === 401 && !isTokenEndpoint) {
        auth.clearSession();
        router.navigate(['/login']);
      }
      return throwError(() => error);
    }),
  );
};