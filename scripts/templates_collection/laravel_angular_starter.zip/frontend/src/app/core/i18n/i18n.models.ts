export interface Language {
  id: number;
  code: string;
  name: string;
  native_name: string;
  flag: string | null;
  is_active: boolean;
  is_default: boolean;
  sort_order: number;
}