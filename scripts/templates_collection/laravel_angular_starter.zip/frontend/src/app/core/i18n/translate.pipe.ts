import { Pipe, PipeTransform, inject } from '@angular/core';
import { I18nService, TranslationKey } from './i18n.service';

/** `{{ 'common_save' | t }}` — impure so it re-renders when the language signal changes. */
@Pipe({ name: 't', pure: false })
export class TranslatePipe implements PipeTransform {
  private i18n = inject(I18nService);

  transform(key: TranslationKey | (string & {}), params?: Record<string, string | number>): string {
    return this.i18n.t(key, params);
  }
}