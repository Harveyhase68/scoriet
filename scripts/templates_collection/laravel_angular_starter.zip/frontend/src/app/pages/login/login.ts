import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthService } from '../../core/auth/auth.service';
import { extractError } from '../../core/auth/http-error';
import { I18nService } from '../../core/i18n/i18n.service';
import { TranslatePipe } from '../../core/i18n/translate.pipe';
import { LanguageSelector } from '../../core/i18n/language-selector';

@Component({
  selector: 'app-login',
  imports: [CommonModule, ReactiveFormsModule, RouterLink, TranslatePipe, LanguageSelector],
  template: `
    <div class="auth-shell">
      <div class="card">
        <div class="row row--between" style="margin-bottom:16px">
          <span></span>
          <app-language-selector />
        </div>

        @if (phase() === 'credentials') {
          <h1>{{ 'login_title' | t }}</h1>
          <p class="subtitle">{{ 'login_subtitle' | t }}</p>

          @if (error()) { <div class="alert alert--error">{{ error() }}</div> }

          <form [formGroup]="form" (ngSubmit)="submit()">
            <div class="field">
              <label for="login-email">{{ 'login_email' | t }}</label>
              <input id="login-email" type="email" formControlName="email" autocomplete="email" />
            </div>
            <div class="field">
              <label for="login-password">{{ 'login_password' | t }}</label>
              <input id="login-password" type="password" formControlName="password" autocomplete="current-password" />
            </div>
            <button class="btn" type="submit" [disabled]="loading() || form.invalid">
              {{ loading() ? ('login_signing_in' | t) : ('login_signin' | t) }}
            </button>
          </form>

          <div class="links">
            <a routerLink="/forgot-password">{{ 'login_forgot' | t }}</a>
            <span class="muted"> · </span>
            <a routerLink="/register">{{ 'login_create_account' | t }}</a>
          </div>
        } @else {
          <h1>{{ 'login_2fa_title' | t }}</h1>
          <p class="subtitle">{{ 'login_2fa_subtitle' | t }}</p>

          @if (error()) { <div class="alert alert--error">{{ error() }}</div> }

          <form [formGroup]="twoFaForm" (ngSubmit)="verify()">
            <div class="field">
              <label for="login-2fa-code">{{ 'login_2fa_code' | t }}</label>
              <input id="login-2fa-code" type="text" formControlName="code" class="mono" autocomplete="one-time-code" inputmode="text" />
            </div>
            <label class="checkbox">
              <input type="checkbox" formControlName="trustDevice" />
              {{ 'login_2fa_trust' | t }}
            </label>
            <button class="btn" type="submit" style="margin-top:16px" [disabled]="loading() || twoFaForm.invalid">
              {{ loading() ? ('login_2fa_verifying' | t) : ('login_2fa_verify' | t) }}
            </button>
          </form>

          <div class="links">
            <a href="#" (click)="cancel2fa($event)">{{ 'login_2fa_back' | t }}</a>
          </div>
        }
      </div>
    </div>
  `,
})
export class Login {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);
  private i18n = inject(I18nService);
  private router = inject(Router);

  phase = signal<'credentials' | 'twofa'>('credentials');
  loading = signal(false);
  error = signal<string | null>(null);

  form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', Validators.required],
  });

  twoFaForm = this.fb.nonNullable.group({
    code: ['', Validators.required],
    trustDevice: [false],
  });

  submit(): void {
    if (this.form.invalid) return;
    this.loading.set(true);
    this.error.set(null);

    const { email, password } = this.form.getRawValue();
    this.auth.login(email, password).subscribe({
      next: (user) => {
        this.i18n.syncFromUser(user.language);
        if (user.two_factor.enabled) {
          this.auth.twoFactorCheckDevice().subscribe({
            next: (res) => {
              this.loading.set(false);
              if (res.trusted) {
                this.router.navigate(['/dashboard']);
              } else {
                this.phase.set('twofa');
              }
            },
            error: () => {
              this.loading.set(false);
              this.phase.set('twofa');
            },
          });
        } else {
          this.loading.set(false);
          this.router.navigate(['/dashboard']);
        }
      },
      error: (err: HttpErrorResponse) => {
        this.loading.set(false);
        this.error.set(
          err.status === 400 || err.status === 401
            ? this.i18n.t('login_invalid')
            : extractError(err),
        );
      },
    });
  }

  verify(): void {
    if (this.twoFaForm.invalid) return;
    this.loading.set(true);
    this.error.set(null);

    const { code, trustDevice } = this.twoFaForm.getRawValue();
    this.auth.twoFactorVerify(code.trim(), trustDevice).subscribe({
      next: () => {
        this.loading.set(false);
        this.router.navigate(['/dashboard']);
      },
      error: (err: HttpErrorResponse) => {
        this.loading.set(false);
        this.error.set(extractError(err));
      },
    });
  }

  cancel2fa(event: Event): void {
    event.preventDefault();
    this.auth.clearSession();
    this.phase.set('credentials');
    this.twoFaForm.reset({ code: '', trustDevice: false });
  }
}