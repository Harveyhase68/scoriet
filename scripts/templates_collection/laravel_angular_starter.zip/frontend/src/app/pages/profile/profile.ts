import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { AuthService } from '../../core/auth/auth.service';
import { extractError } from '../../core/auth/http-error';
import { I18nService } from '../../core/i18n/i18n.service';
import { TranslatePipe } from '../../core/i18n/translate.pipe';

@Component({
  selector: 'app-profile',
  imports: [CommonModule, ReactiveFormsModule, RouterLink, TranslatePipe],
  templateUrl: './profile.html',
})
export class Profile {
  private fb = inject(FormBuilder);
  private sanitizer = inject(DomSanitizer);
  private i18n = inject(I18nService);
  auth = inject(AuthService);
  private router = inject(Router);

  // ---- profile ----
  profileForm = this.fb.nonNullable.group({
    name: [this.auth.user()?.name ?? '', Validators.required],
    email: [this.auth.user()?.email ?? '', [Validators.required, Validators.email]],
  });
  profileMsg = signal<{ type: 'error' | 'success'; text: string } | null>(null);
  profileSaving = signal(false);

  // ---- password ----
  passwordForm = this.fb.nonNullable.group({
    current_password: ['', Validators.required],
    password: ['', [Validators.required, Validators.minLength(8)]],
    password_confirmation: ['', Validators.required],
  });
  passwordMsg = signal<{ type: 'error' | 'success'; text: string } | null>(null);
  passwordSaving = signal(false);

  // ---- avatar ----
  avatarMsg = signal<{ type: 'error' | 'success'; text: string } | null>(null);
  avatarUploading = signal(false);

  // ---- 2fa ----
  twoFaStep = signal<'idle' | 'enabling'>('idle');
  twoFaMsg = signal<{ type: 'error' | 'success'; text: string } | null>(null);
  twoFaBusy = signal(false);
  qrSvg = signal<SafeHtml | null>(null);
  secret = signal<string | null>(null);
  recoveryCodes = signal<string[] | null>(null);

  enableForm = this.fb.nonNullable.group({ password: ['', Validators.required] });
  confirmForm = this.fb.nonNullable.group({
    code: ['', [Validators.required, Validators.minLength(6)]],
    trustDevice: [false],
  });
  disableForm = this.fb.nonNullable.group({
    password: ['', Validators.required],
    code: ['', Validators.required],
  });

  // ------------------------------------------------------- profile actions

  saveProfile(): void {
    if (this.profileForm.invalid) return;
    this.profileSaving.set(true);
    this.profileMsg.set(null);
    this.auth.updateProfile(this.profileForm.getRawValue()).subscribe({
      next: () => {
        this.profileSaving.set(false);
        this.profileMsg.set({ type: 'success', text: this.i18n.t('profile_msg_updated') });
      },
      error: (err: HttpErrorResponse) => {
        this.profileSaving.set(false);
        this.profileMsg.set({ type: 'error', text: extractError(err) });
      },
    });
  }

  savePassword(): void {
    if (this.passwordForm.invalid) return;
    this.passwordSaving.set(true);
    this.passwordMsg.set(null);
    this.auth.updatePassword(this.passwordForm.getRawValue()).subscribe({
      next: () => {
        this.passwordSaving.set(false);
        this.passwordMsg.set({ type: 'success', text: this.i18n.t('profile_msg_password_changed') });
        this.passwordForm.reset({ current_password: '', password: '', password_confirmation: '' });
      },
      error: (err: HttpErrorResponse) => {
        this.passwordSaving.set(false);
        this.passwordMsg.set({ type: 'error', text: extractError(err) });
      },
    });
  }

  // -------------------------------------------------------- avatar actions

  onAvatarSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    this.avatarUploading.set(true);
    this.avatarMsg.set(null);
    this.auth.uploadAvatar(file).subscribe({
      next: () => {
        this.avatarUploading.set(false);
        this.avatarMsg.set({ type: 'success', text: this.i18n.t('profile_msg_avatar_updated') });
        input.value = '';
      },
      error: (err: HttpErrorResponse) => {
        this.avatarUploading.set(false);
        this.avatarMsg.set({ type: 'error', text: extractError(err) });
      },
    });
  }

  removeAvatar(): void {
    this.auth.deleteAvatar().subscribe({
      next: () => this.avatarMsg.set({ type: 'success', text: this.i18n.t('profile_msg_avatar_removed') }),
      error: (err: HttpErrorResponse) => this.avatarMsg.set({ type: 'error', text: extractError(err) }),
    });
  }

  // ----------------------------------------------------------- 2fa actions

  startEnable(): void {
    if (this.enableForm.invalid) return;
    this.twoFaBusy.set(true);
    this.twoFaMsg.set(null);
    this.auth.twoFactorEnable(this.enableForm.getRawValue().password).subscribe({
      next: (res) => {
        this.twoFaBusy.set(false);
        this.qrSvg.set(this.sanitizer.bypassSecurityTrustHtml(res.qr_code_svg));
        this.secret.set(res.secret);
        this.twoFaStep.set('enabling');
        this.enableForm.reset({ password: '' });
      },
      error: (err: HttpErrorResponse) => {
        this.twoFaBusy.set(false);
        this.twoFaMsg.set({ type: 'error', text: extractError(err) });
      },
    });
  }

  confirmEnable(): void {
    if (this.confirmForm.invalid) return;
    this.twoFaBusy.set(true);
    this.twoFaMsg.set(null);
    const { code, trustDevice } = this.confirmForm.getRawValue();
    this.auth.twoFactorConfirm(code.trim(), trustDevice).subscribe({
      next: (res) => {
        this.twoFaBusy.set(false);
        this.recoveryCodes.set(res.recovery_codes);
        this.twoFaStep.set('idle');
        this.qrSvg.set(null);
        this.secret.set(null);
        this.confirmForm.reset({ code: '', trustDevice: false });
        this.twoFaMsg.set({ type: 'success', text: this.i18n.t('profile_msg_2fa_enabled') });
      },
      error: (err: HttpErrorResponse) => {
        this.twoFaBusy.set(false);
        this.twoFaMsg.set({ type: 'error', text: extractError(err) });
      },
    });
  }

  cancelEnable(): void {
    this.auth.twoFactorStatus().subscribe();
    this.twoFaStep.set('idle');
    this.qrSvg.set(null);
    this.secret.set(null);
  }

  disable(): void {
    if (this.disableForm.invalid) return;
    this.twoFaBusy.set(true);
    this.twoFaMsg.set(null);
    const { password, code } = this.disableForm.getRawValue();
    this.auth.twoFactorDisable(password, code.trim()).subscribe({
      next: () => {
        this.twoFaBusy.set(false);
        this.recoveryCodes.set(null);
        this.disableForm.reset({ password: '', code: '' });
        this.twoFaMsg.set({ type: 'success', text: this.i18n.t('profile_msg_2fa_disabled') });
      },
      error: (err: HttpErrorResponse) => {
        this.twoFaBusy.set(false);
        this.twoFaMsg.set({ type: 'error', text: extractError(err) });
      },
    });
  }

  logout(): void {
    this.auth.logout().subscribe(() => this.router.navigate(['/login']));
  }
}