import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth/auth.service';
import { TranslatePipe } from '../../core/i18n/translate.pipe';

@Component({
  selector: 'app-dashboard',
  imports: [CommonModule, RouterLink, TranslatePipe],
  template: `
    <div class="auth-shell">
      <div class="card card--wide">
        <div class="row row--between">
          <h1>{{ 'dashboard_title' | t }}</h1>
          <button class="btn btn--ghost btn--auto" (click)="logout()">{{ 'dashboard_logout' | t }}</button>
        </div>

        @if (auth.user(); as user) {
          <p class="subtitle">{{ 'dashboard_signed_in_as' | t }} <strong>{{ user.name }}</strong> ({{ user.email }})</p>

          <div class="row" style="gap:16px;margin:20px 0">
            @if (user.avatar_url) {
              <img [src]="user.avatar_url" alt="avatar"
                   style="width:64px;height:64px;border-radius:50%;object-fit:cover" />
            }
            <div>
              <div>{{ 'dashboard_2fa' | t }}: <strong>{{ user.two_factor.enabled ? ('dashboard_enabled' | t) : ('dashboard_disabled' | t) }}</strong></div>
              <div class="muted">{{ 'dashboard_member_since' | t }} {{ user.created_at | date: 'mediumDate' }}</div>
            </div>
          </div>

          <hr class="divider" />
          <a class="btn btn--auto" routerLink="/profile">{{ 'dashboard_manage_profile' | t }}</a>
        }
      </div>
    </div>
  `,
})
export class Dashboard {
  auth = inject(AuthService);
  private router = inject(Router);

  logout(): void {
    this.auth.logout().subscribe(() => this.router.navigate(['/login']));
  }
}