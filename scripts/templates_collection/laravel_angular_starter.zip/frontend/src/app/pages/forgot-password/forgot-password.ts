import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { AuthService } from '../../core/auth/auth.service';
import { extractError } from '../../core/auth/http-error';
import { TranslatePipe } from '../../core/i18n/translate.pipe';

@Component({
  selector: 'app-forgot-password',
  imports: [CommonModule, ReactiveFormsModule, RouterLink, TranslatePipe],
  template: `
    <div class="auth-shell">
      <div class="card">
        <h1>{{ 'forgot_title' | t }}</h1>
        <p class="subtitle">{{ 'forgot_subtitle' | t }}</p>

        @if (error()) { <div class="alert alert--error">{{ error() }}</div> }
        @if (success()) { <div class="alert alert--success">{{ success() }}</div> }

        <form [formGroup]="form" (ngSubmit)="submit()">
          <div class="field">
            <label for="forgot-email">{{ 'forgot_email' | t }}</label>
            <input id="forgot-email" type="email" formControlName="email" autocomplete="email" />
          </div>
          <button class="btn" type="submit" [disabled]="loading() || form.invalid">
            {{ loading() ? ('forgot_sending' | t) : ('forgot_submit' | t) }}
          </button>
        </form>

        <div class="links"><a routerLink="/login">{{ 'forgot_back' | t }}</a></div>
      </div>
    </div>
  `,
})
export class ForgotPassword {
  private fb = inject(FormBuilder);
  private auth = inject(AuthService);

  loading = signal(false);
  error = signal<string | null>(null);
  success = signal<string | null>(null);

  form = this.fb.nonNullable.group({
    email: ['', [Validators.required, Validators.email]],
  });

  submit(): void {
    if (this.form.invalid) return;
    this.loading.set(true);
    this.error.set(null);
    this.success.set(null);

    this.auth.forgotPassword(this.form.getRawValue().email).subscribe({
      next: (res) => {
        this.loading.set(false);
        this.success.set(res.message);
      },
      error: (err: HttpErrorResponse) => {
        this.loading.set(false);
        this.error.set(extractError(err));
      },
    });
  }
}