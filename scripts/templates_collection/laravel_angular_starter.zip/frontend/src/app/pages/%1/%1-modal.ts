import { Component, inject, output, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { ApiService } from '../../core/api/api.service';
import { extractError } from '../../core/auth/http-error';
import { TranslatePipe } from '../../core/i18n/translate.pipe';

/**
 * Modal overlay for quickly creating a {:filesingular:} from within another
 * table's form, without leaving the page (used as an FK "+ Add" lookup).
 */
@Component({
  selector: 'app-{:filename:}-modal',
  imports: [CommonModule, ReactiveFormsModule, TranslatePipe],
  template: `
    <!-- Backdrop click-to-close is a convenience; Escape and the Cancel button are the accessible paths. -->
    <!-- eslint-disable-next-line @angular-eslint/template/interactive-supports-focus -->
    <div class="modal-backdrop" (click)="cancel()" (keydown.escape)="cancel()">
      <!-- eslint-disable-next-line @angular-eslint/template/click-events-have-key-events, @angular-eslint/template/interactive-supports-focus -->
      <div class="modal-card" (click)="$event.stopPropagation()">
        <h2>{:filecaption:}</h2>

        @if (error()) {
          <div class="alert alert--error">{{ error() }}</div>
        }

        <form [formGroup]="form" (ngSubmit)="submit()">
{:for nmaxitemsnokey:}
{:if item.istimestamp:}
{:elseif item.isforeign:}
{:elseif item.phptype eq 'bool':}
          <div class="field">
            <label class="checkbox">
              <input type="checkbox" formControlName="{:item.name:}" />
              {:item.caption:}
            </label>
          </div>
{:elseif item.isblob:}
          <div class="field">
            <label for="{:filename:}-modal-{:item.name:}">{:item.caption:}</label>
            <textarea id="{:filename:}-modal-{:item.name:}" formControlName="{:item.name:}" rows="3"></textarea>
          </div>
{:elseif item.phptype eq 'int':}
          <div class="field">
            <label for="{:filename:}-modal-{:item.name:}">{:item.caption:}</label>
            <input id="{:filename:}-modal-{:item.name:}" type="number" formControlName="{:item.name:}" />
          </div>
{:elseif item.phptype eq 'float':}
          <div class="field">
            <label for="{:filename:}-modal-{:item.name:}">{:item.caption:}</label>
            <input id="{:filename:}-modal-{:item.name:}" type="number" step="0.01" formControlName="{:item.name:}" />
          </div>
{:else:}
          <div class="field">
            <label for="{:filename:}-modal-{:item.name:}">{:item.caption:}</label>
            <input id="{:filename:}-modal-{:item.name:}" type="text" formControlName="{:item.name:}" />
          </div>
{:endif:}
{:endfor:}

          <div class="row row--between" style="margin-top:8px">
            <button type="button" class="btn btn--ghost btn--auto" (click)="cancel()">{{ 'common_cancel' | t }}</button>
            <button type="submit" class="btn btn--auto" [disabled]="saving() || form.invalid">
              {{ saving() ? ('common_saving' | t) : ('common_save' | t) }}
            </button>
          </div>
        </form>
      </div>
    </div>
  `,
})
export class {:filepascalcase:}Modal {
  private fb = inject(FormBuilder);
  private api = inject(ApiService);

  closed = output<void>();
  saved = output<any>();

  saving = signal(false);
  error = signal<string | null>(null);

  form = this.fb.nonNullable.group({
{:for nmaxitemsnokey:}
{:if item.istimestamp:}
{:elseif item.isforeign:}
{:elseif item.phptype eq 'bool':}
    {:item.name:}: [false],
{:else:}
    {:item.name:}: [''{:if item.notnull:}, Validators.required{:endif:}],
{:endif:}
{:endfor:}
  });

  submit(): void {
    if (this.form.invalid) return;
    this.saving.set(true);
    this.error.set(null);

    this.api.create{:filepascalcase:}(this.form.getRawValue()).subscribe({
      next: (res) => {
        this.saving.set(false);
        this.form.reset();
        this.saved.emit(res.{:filesingular:});
      },
      error: (err: HttpErrorResponse) => {
        this.saving.set(false);
        this.error.set(extractError(err));
      },
    });
  }

  cancel(): void {
    this.error.set(null);
    this.closed.emit();
  }
}