<?php
session_start();

require_once('class.user.php');
require_once("config.php");

$user = new USER();

if ($user->is_loggedin() != "") {
    $user->redirect('home.php');
}

if (isset($_POST['btn-signup'])) {

    $uname = strip_tags($_POST['txt_uname']);
    $umail = strip_tags($_POST['txt_umail']);
    $upass = strip_tags($_POST['txt_upass']);

    if (isset($_SERVER['REMOTE_ADDR'])) {
        $uIP = $_SERVER['REMOTE_ADDR'];
    } else {
        $uIP = "";
    }

    if ($uname == "") {
        $error[] = "Bitte geben Sie einen Benutzernamen an !";
    } else if ($umail == "") {
        $error[] = "Bitte geben Sie eine Email Adresse an !";
    } else if (!filter_var($umail, FILTER_VALIDATE_EMAIL)) {
        $error[] = 'Bitte geben Sie eine gültige Email Adresse an !';
    } else if ($upass == "") {
        $error[] = "Wählen Sie ein Passwort !";
    } else if (strlen($upass) < 6) {
        $error[] = "Passwort muss mindestens 6 Stellen haben";
    } else {
        try {
            $stmt = $user->runQuery("SELECT user_name, user_email FROM users WHERE user_name=:uname OR user_email=:umail");
            $stmt->execute(array(':uname' => $uname, ':umail' => $umail));
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
			if ($stmt->rowCount() == 1) {
				if ($row['user_name'] == $uname) {
					$error[] = "Benutzername ist bereits vergeben !";
				} else if ($row['user_email'] == $umail) {
					$error[] = "Email Adresse ist bereits vergeben !";
				}
			} else {
				$ret = $user->register($uname, $umail, $upass, $uIP);
				if (substr($ret, 0, 1) == "1") {
					$user->redirect('sign-up.php?joined');
				} else {
					$error[] = substr($ret, 2);
				}
			}
        } catch (PDOException $e) {
            echo $e->getMessage();
        }
    }
}

include_once("header.php");

?>
    <body onload="document.getElementById('captcha-form').focus()">

<div class="signin-form">

    <div class="container">

        <form method="post" class="form-signin">
            <div class="form-inner-container">
                <center><td><?php echo COMPANY_HEADER; ?></center>
                <h2 class="form-signin-heading">Kunden Registrierung</h2>
                <hr/>
                <?php
                if (isset($error)) {
                    foreach ($error as $error) {
                        ?>
                        <div class="alert alert-danger">
                            <i class="glyphicon glyphicon-warning-sign"></i> &nbsp; <?php echo $error; ?>
                        </div>
                        <?php
                    }
                } else if (isset($_GET['joined'])) {
                    ?>
                    <div class="alert alert-info">
                        <i class="glyphicon glyphicon-log-in"></i> &nbsp; Sie haben eine Email erhalten, bestätigen Sie
                        nun
                        Ihre Email Adresse indem Sie auf den Link drücken, danach können Sie sich einloggen! <a
                                href='index.php'>Zum Login</a>
                    </div>
                    <?php
                }
                ?>
                <div class="form-group">
                    <input type="text" class="form-control" name="txt_uname" placeholder="Benutzername"
                           value="<?php if (isset($error)) {
                               echo $uname;
                           } ?>"/>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" name="txt_umail" placeholder="Email"
                           value="<?php if (isset($error)) {
                               echo $umail;
                           } ?>"/>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="txt_upass"
                           placeholder="Passwort (6 Stellen min)"/>
                </div>
                <div class="clearfix"></div>
                <hr/>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary" name="btn-signup">
                        <i class="glyphicon glyphicon-open-file"></i>&nbsp;Registrieren
                    </button>
                </div>
                <hr/>
                <label>Ich habe mich bereits registriert ! <a href="index.php">Zum Login</a></label>
            </div>
            <div style="text-align: right;">
                <span class="copyright"><?php echo FOOTER; ?></span>
            </div>
        </form>
    </div>
</div>
<?php
include_once("footer.php");