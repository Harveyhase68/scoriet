// SCORIET-OUTPUT-PATH: {:projectname:}/Entities/Identity/Benutzer.cs
using Microsoft.AspNetCore.Identity;

namespace {:projectname:}.Entities.Identity;

public class Benutzer : IdentityUser<long>
{
    public string UserNo { get; set; } = default!;
    public string TenantNo { get; set; } = default!;
    public string DisplayName { get; set; } = default!;
    /// <summary>Hex-Farbcode (z.B. "#1976D2"), nullable.</summary>
    public string? Color { get; set; }
}