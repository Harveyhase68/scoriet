# Scoriet Blazor Template

Scoriet-Importvorlage für eine Blazor-Web-App (.NET 10, MudBlazor, EF Core, PostgreSQL,
Identity + Passport-ähnliche Passwort-Policy, QuestPDF-Reports). Aus einem Datenbank-Schema
generiert Scoriet eine komplette CRUD-Anwendung.

## Verzeichnisstruktur

```
scoriet_blazor_template/
├── Directory.Packages.props           NuGet Central Package Versions
├── blazor_template.slnx               Solution (→ {:projectname:}.slnx)
├── blazor_template.code-workspace     VS Code Workspace
├── blazor_template/                   Server-Projekt (→ {:projectname:}/)
│   ├── blazor_template.csproj         (→ {:projectname:}.csproj)
│   ├── Program.cs                     DI, Auth, DB-Connection
│   ├── appsettings*.json              ConnectionString mit {:projectdb*:} Placeholdern
│   ├── Data/
│   │   ├── ScorietDbContext.cs        (→ {:projectname:}DbContext.cs) iteriert Tabellen
│   │   ├── ITenantProvider.cs         Mandanten-Scope via Claim
│   │   ├── BenutzerClaimsPrincipalFactory.cs
│   │   └── PasswordScoring.cs         Score-based Passwort-Policy
│   ├── Entities/
│   │   ├── Common/TenantEntity.cs     Basisklasse (TenantNo)
│   │   ├── Identity/Benutzer.cs       IdentityUser<long>
│   │   ├── Tenants/Tenant.cs          Mandanten-Entity
│   │   └── _TABLE_ENTITY.cs           ⭐ PER-TABLE-Template (iteriert Felder)
│   ├── Components/
│   │   ├── App.razor, Routes.razor, _Imports.razor
│   │   ├── Pages/Dashboard.razor      Start-Page (leer)
│   │   ├── Pages/Error.razor
│   │   ├── Pages/Konto/Login.razor
│   │   └── Pages/_TABLE_List.razor    ⭐ PER-TABLE-Template (CRUD-Liste)
│   │   └── Pages/_TABLE_Edit.razor    ⭐ PER-TABLE-Template (CRUD-Edit)
│   ├── Reports/
│   │   ├── PdfReportService.cs        QuestPDF BuildList / BuildRecord
│   │   └── PdfDownloadExtensions.cs
│   └── wwwroot/
│       └── _projectname_.js           (→ {:lower(projectname):}.js)
└── blazor_template.Client/            WASM-Client (→ {:projectname:}.Client/)
    ├── blazor_template.Client.csproj  (→ {:projectname:}.Client.csproj)
    ├── Program.cs
    ├── _Imports.razor
    ├── Layout/
    │   ├── MainLayout.razor           AppBar mit {:projectname:} Titel
    │   ├── NavMenu.razor              ⭐ LEER — iteriert Tabellen zur Generation
    │   ├── TopBar.razor, BreadcrumbBar.razor, LiveClock.razor, LoginDisplay.razor
    │   └── EmptyLayout.razor
    ├── Components/RedirectToLogin.razor
    └── Pages/NotFound.razor
```

⭐-Dateien sind *per-table*-Templates: aus einer Vorlage entsteht eine Ausgabedatei pro
Schema-Tabelle.

## Platzhalter

### Projektweit (Scoriet-Standard-Placeholders)

| Placeholder | Bedeutung | Typische Auflösung |
|---|---|---|
| `{:projectname:}` | Projekt-Name (CamelCase — dient als C#-Namespace, Class-Suffix, Cookie-Präfix, Title) | `MyCoolApp` |
| `{:lower(projectname):}` | Kleinschreibung (für Cookie-Name, JS-Namespace, Drawer-Storage-Key) | `mycoolapp` |
| `{:projectdbserver:}` | DB-Host | `localhost` |
| `{:projectdbport:}` | DB-Port | `5432` |
| `{:projectdbname:}` | DB-Datenbankname | `mycoolapp_db` |
| `{:projectdbusername:}` | DB-User | `postgres` |
| `{:projectdbpassword:}` | DB-Passwort | `admin` |
| `{:currencysym:}` | Währungssymbol (Projekt-Setting) | `€` |

### Tabellen-Iteration (`{:for nmaxtables:}`)

| Placeholder | Bedeutung |
|---|---|
| `{:table.filename:}` | SQL-Tabellenname (z.B. `customers`) |
| `{:table.filepascalcase:}` | PascalCase Plural (z.B. `Customers`) |
| `{:table.filesingularpascalcase:}` | PascalCase Singular (z.B. `Customer`) |
| `{:table.primarykeyfield:}` | Primary-Key-Feldname |
| `{:lower(table.filepascalcase):}` | lowercase Plural (URL-Slug) |

### Feld-Iteration (`{:for nmaxitems:}`)

| Placeholder | Bedeutung |
|---|---|
| `{:item.name:}` | Feldname |
| `{:item.pascalcase:}` | PascalCase (C#-Property) |
| `{:item.type:}` | SQL-Typ (`VARCHAR`, `INT`, `DECIMAL`, `DATE`, ...) |
| `{:item.caption:}` | Feld-Caption (aus Übersetzungen) |
| `{:item.isnullable:}` | Bool für `{:if:}` |
| `{:item.maxlength:}` | String-Länge |

### Layout aus dem Form-Designer

Scoriet bringt pro Schema-Tabelle ein FormSet mit 3 Fenstern mit: `main_menu`,
`create_edit`, `data_table`. Die Platzhalter hier lesen die **FormItemPlacement**-Records
(Breite, Höhe, Position, Caption-Position, Label-Breite, Control-Type, Lookup-Konfig,
Button-Farben).

**Direktzugriff auf das Fenster:**
`{:formset.create_edit.default_width:}`, `{:formset.data_table.background_color:}`, ...

**Pro-Feld-Iteration im `create_edit`-Fenster:** `{:for nmaxlayoutsingles:}`
- `{:item.width:}`, `{:item.height:}` — px
- `{:item.label:}` — Beschriftung
- `{:item.label_position:}` — `top` / `left` / `right`
- `{:item.label_width:}` — px (für label_position=left)
- `{:item.control_type:}` — `text` / `textarea` / `integer` / `float` / `currency`
  / `date` / `time` / `datetime` / `checkbox` / `combobox` / `color` / `file`
  / `password` / `readonly`
- `{:item.field_name:}` — Original SQL-Feldname
- `{:item.lookup_table:}`, `{:item.lookup_value:}`, `{:item.lookup_display:}` — für Combobox

**Button-Iteration:** `{:for nmaxlayoutbuttons:}`
- `{:item.label:}`, `{:item.icon:}`, `{:item.action:}` — `save`/`cancel`/`delete`/`print`/`new`/`nav_first`/`nav_prev`/`nav_next`/`nav_last`/`close`
- `{:item.background_color:}`, `{:item.text_color:}`
- `{:item.width:}`, `{:item.height:}`

### Datei-/Pfad-Placeholders (`%x` in `file_name` und `output_path`)

Diese Platzhalter sind NICHT für Datei-Inhalte, sondern ausschließlich für Dateinamen
und Zielpfade (beim Anlegen eines Template-Files im Scoriet File-Modal).

| Placeholder | Beispiel | Ergebnis für Projekt „csharp_postgresql" / Tabelle `addresses` |
|---|---|---|
| `%1` | `%1.razor` | `addresses.razor` — SQL-Tabellenname |
| `%10` | `%10.cs` | `Addresses.cs` — Tabelle Ucfirst |
| `%11` | `%11.sql` | `ADDRESSES.sql` — Tabelle UPPERCASE |
| `%2` | `i18n_%2.json` | `i18n_de.json` — Sprachcode |
| `%5` | `%5.md` | `blazor_template.md` — Template-Name |
| `%6[-]` | `log_%6[-].txt` | `log_2026-04-20.txt` — Datum (ISO mit Trenner) |
| `%7[:]` | `%7[:].log` | `09:50:34.log` — Zeit mit Trenner |
| `%9` | `%9.csproj` | `csharp_postgresql.csproj` — **Projektname** (neu) |
| `%9[u]` | `%9[u].env` | `CSHARP_POSTGRESQL.env` — UPPER |
| `%9[l]` | `%9[l].yml` | `csharp_postgresql.yml` — lower |
| `%9[c]` | `%9[c].ts` | `csharpPostgresql.ts` — camelCase |
| `%9[p]` | `%9[p].csproj` | `CsharpPostgresql.csproj` — PascalCase |
| `%9[n]` | `%9[n]/Readme.md` | `Csharp Postgresql/Readme.md` — Nice print |
| `%12` / `%12[06]` | `step_%12[03].sql` | `step_001.sql` — Counter pro File (zero-padded) |
| `%13` / `%13[06]` | `mig_%13[06].sql` | `mig_000020.sql` — Globaler Counter über alle db_table_files |
| `%14` | `schema_v%14.sql` | `schema_v3.sql` — **DB-Version** (war vor dem Refactor `%9`) |

Damit kann man z.B. die `.csproj`-Datei direkt auf `%9[p].csproj` setzen und erhält
`CsharpPostgresql.csproj` — ohne im Datei-Inhalt `{:projectname:}` verwenden zu müssen.

## Import in Scoriet

1. Ordner zippen (`scoriet_blazor_template.zip`).
2. In Scoriet: Templates → Import → ZIP hochladen.
3. Für jede Template-Datei den `output_path` konfigurieren — entspricht dem Kommentar
   `// SCORIET-OUTPUT-PATH: …` in Zeile 1 jeder Datei. Beispiele:
   - `blazor_template/Program.cs` → `{:projectname:}/Program.cs`
   - `blazor_template/Data/ScorietDbContext.cs` → `{:projectname:}/Data/{:projectname:}DbContext.cs`
   - `blazor_template.slnx` → `{:projectname:}.slnx`
   - `blazor_template/Entities/_TABLE_ENTITY.cs` → `{:projectname:}/Entities/{:table.filepascalcase:}/{:table.filesingularpascalcase:}.cs` (**per-table**)
   - `blazor_template/Components/Pages/_TABLE_List.razor` → `{:projectname:}/Components/Pages/Stammdaten/{:table.filepascalcase:}/List.razor` (**per-table**)
   - `blazor_template/Components/Pages/_TABLE_Edit.razor` → `{:projectname:}/Components/Pages/Stammdaten/{:table.filepascalcase:}/Edit.razor` (**per-table**)
4. Die 3 **per-table**-Files (`_TABLE_*`) als `form_window_type` (2=create_edit, 3=data_table)
   bzw. Entity-Typ markieren, damit Scoriet pro Schema-Tabelle eine Ausgabe erzeugt.
5. Projekt anlegen mit:
   - Projekt-Name (`{:projectname:}`)
   - DB-Verbindung (`{:projectdb*:}`)
   - FormSet auswählen (oder Standard 800×600 nutzen)
   - Schema importieren (MySQL/PostgreSQL)
6. Code generieren — es entsteht ein vollständiges `.NET 10` Blazor-Projekt mit `.slnx`,
   `csproj`, DbContext, Entities, CRUD-Seiten, NavMenu, PDF-Reports.

## Enthaltene Control-Typen (FormItemPlacement.control_type)

Der generische `Edit.razor`-Switch unterstützt:

| control_type | MudBlazor-Komponente |
|---|---|
| `text` | `MudTextField` einzeilig |
| `textarea` | `MudTextField` mit `Lines="4"` |
| `integer` | `MudNumericField<int>` |
| `float` | `MudNumericField<double>` |
| `currency` | `MudNumericField<decimal>` + `AdornmentText="{:currencysym:}"` |
| `date` | `MudDatePicker` |
| `time` | `MudTimePicker` |
| `datetime` | `MudDatePicker` + `MudTimePicker` (nebeneinander) |
| `checkbox` | `MudCheckBox<bool>` (Label rechts) |
| `combobox` | `MudSelect<string>` — mit Lookup-Tabelle oder festen Werten |
| `color` | `MudColorPicker` |
| `file` | `MudFileUpload` (Upload nach `wwwroot/uploads/<table>/<guid>.<ext>`) |
| `password` | `MudTextField` mit `InputType="InputType.Password"` |
| `readonly` | `MudTextField` mit `ReadOnly="true"` |

Caption-Position `top` / `left` / `right` wird berücksichtigt, `label_width` in px
ebenfalls. Breite/Höhe jedes Controls kommt pixelgenau aus `FormItemPlacement`.

## Nach dem Generieren

```bash
cd <generated-project>
dotnet restore
dotnet ef migrations add InitialCreate --project {:projectname:} --startup-project {:projectname:}
dotnet ef database update --project {:projectname:} --startup-project {:projectname:}
dotnet run --project {:projectname:}
```

## Bekannte Annahmen

- **PostgreSQL** via Npgsql + EFCore.NamingConventions (snake_case).
  Für MySQL-Projekte: `appsettings*.json` → Provider auf `Pomelo.EntityFrameworkCore.MySql`
  umstellen + `UseMySql(...)` in `Program.cs`.
- **.NET 10** Zielframework (kann in `csproj` auf `net8.0` o.ä. reduziert werden).
- **Mandanten-Scoped:** Jede generierte Entity erbt `TenantEntity`, jede Query filtert auf
  `TenantNo == Tenant.TenantNo`. Für nicht-mandantenfähige Projekte: `TenantEntity`-Basis
  entfernen und im DbContext Template die `HasIndex(TenantNo)` Zeile löschen.
- **Identity:** Cookie-Auth, Rolle `IdentityRole<long>`, Benutzer erbt `IdentityUser<long>`.