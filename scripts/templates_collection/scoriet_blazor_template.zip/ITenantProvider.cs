// SCORIET-OUTPUT-PATH: {:projectname:}/Data/ITenantProvider.cs
using System.Security.Claims;

namespace {:projectname:}.Data;

public interface ITenantProvider
{
    string? TenantNo { get; }
}

public sealed class HttpContextTenantProvider : ITenantProvider
{
    public const string TenantClaimType = "{:lower(projectname):}:tenant_no";

    private readonly IHttpContextAccessor _accessor;

    public HttpContextTenantProvider(IHttpContextAccessor accessor) => _accessor = accessor;

    public string? TenantNo => _accessor.HttpContext?.User.FindFirst(TenantClaimType)?.Value;
}