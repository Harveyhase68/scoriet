// SCORIET-OUTPUT-PATH: {:projectname:}/wwwroot/{:lower(projectname):}.js
window.{:lower(projectname):} = window.{:lower(projectname):} || {};

window.{:lower(projectname):}.downloadFile = function (fileName, base64, mimeType) {
    const link = document.createElement('a');
    link.href = `data:${mimeType};base64,${base64}`;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};