// SCORIET-OUTPUT-PATH: {:projectname:}/Reports/PdfDownloadExtensions.cs
using Microsoft.JSInterop;

namespace {:projectname:}.Reports;

public static class PdfDownloadExtensions
{
    public static ValueTask DownloadPdfAsync(this IJSRuntime js, string fileName, byte[] bytes) =>
        js.InvokeVoidAsync("{:lower(projectname):}.downloadFile",
            fileName, Convert.ToBase64String(bytes), "application/pdf");

    public static string TimestampFileName(string prefix) =>
        $"{prefix}_{DateTime.Now:yyyyMMdd_HHmmss}.pdf";
}