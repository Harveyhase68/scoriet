// SCORIET-OUTPUT-PATH: {:projectname:}/Entities/{:table.filepascalcase:}/{:table.filesingularpascalcase:}.cs
// Per-table entity template. Scoriet writes ONE .cs file per schema table,
// substituting {:table.*:} and iterating fields via {:for nmaxitems:}.
using {:projectname:}.Entities.Common;

namespace {:projectname:}.Entities.{:table.filepascalcase:};

public class {:table.filesingularpascalcase:} : TenantEntity
{
    {:for nmaxitems:}
    {:if item.isnullable:}
    {:if item.type eq "INT" or item.type eq "INTEGER" or item.type eq "SMALLINT":}
    public int? {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "BIGINT":}
    public long? {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "DECIMAL" or item.type eq "NUMERIC" or item.type eq "MONEY":}
    public decimal? {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "FLOAT" or item.type eq "DOUBLE" or item.type eq "REAL":}
    public double? {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "BOOL" or item.type eq "BOOLEAN" or item.type eq "BIT":}
    public bool? {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "DATE":}
    public DateOnly? {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "TIME":}
    public TimeOnly? {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "DATETIME" or item.type eq "TIMESTAMP":}
    public DateTime? {:item.pascalcase:} { get; set; }
    {:else:}
    public string? {:item.pascalcase:} { get; set; }
    {:endif:}
    {:else:}
    {:if item.type eq "INT" or item.type eq "INTEGER" or item.type eq "SMALLINT":}
    public int {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "BIGINT":}
    public long {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "DECIMAL" or item.type eq "NUMERIC" or item.type eq "MONEY":}
    public decimal {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "FLOAT" or item.type eq "DOUBLE" or item.type eq "REAL":}
    public double {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "BOOL" or item.type eq "BOOLEAN" or item.type eq "BIT":}
    public bool {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "DATE":}
    public DateOnly {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "TIME":}
    public TimeOnly {:item.pascalcase:} { get; set; }
    {:elseif item.type eq "DATETIME" or item.type eq "TIMESTAMP":}
    public DateTime {:item.pascalcase:} { get; set; } = DateTime.UtcNow;
    {:else:}
    public string {:item.pascalcase:} { get; set; } = default!;
    {:endif:}
    {:endif:}
    {:endfor:}
}