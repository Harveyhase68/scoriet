// SCORIET-OUTPUT-PATH: {:projectname:}/Data/PasswordScoring.cs
using {:projectname:}.Entities.Identity;
using Microsoft.AspNetCore.Identity;

namespace {:projectname:}.Data;

public static class PasswordScoring
{
    public const int MinLength = 8;
    public const int MinScore = 90;

    public static int Score(string? password)
    {
        if (string.IsNullOrEmpty(password)) return 0;
        var s = password.Length * 5;
        if (password.Any(char.IsLower)) s += 5;
        if (password.Any(char.IsUpper)) s += 10;
        if (password.Any(char.IsDigit)) s += 10;
        if (password.Any(c => !char.IsLetterOrDigit(c))) s += 15;
        return Math.Min(100, s);
    }

    public static bool Passes(string? password) =>
        !string.IsNullOrEmpty(password)
        && password.Length >= MinLength
        && Score(password) >= MinScore;
}

public sealed class ScoreBasedPasswordValidator : IPasswordValidator<Benutzer>
{
    public Task<IdentityResult> ValidateAsync(
        UserManager<Benutzer> manager, Benutzer user, string? password)
    {
        if (string.IsNullOrEmpty(password) || password.Length < PasswordScoring.MinLength)
        {
            return Task.FromResult(IdentityResult.Failed(new IdentityError
            {
                Code = "PasswordTooShort",
                Description = $"Passwort zu kurz (mindestens {PasswordScoring.MinLength} Zeichen).",
            }));
        }

        var score = PasswordScoring.Score(password);
        if (score >= PasswordScoring.MinScore)
            return Task.FromResult(IdentityResult.Success);

        return Task.FromResult(IdentityResult.Failed(new IdentityError
        {
            Code = "PasswordTooWeak",
            Description = $"Passwort zu schwach (Staerke {score}/100, mindestens {PasswordScoring.MinScore}). " +
                          "Entweder laenger machen oder Gross-/Ziffer-/Sonderzeichen kombinieren.",
        }));
    }
}