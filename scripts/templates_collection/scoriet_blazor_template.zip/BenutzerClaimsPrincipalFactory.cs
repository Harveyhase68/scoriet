// SCORIET-OUTPUT-PATH: {:projectname:}/Data/BenutzerClaimsPrincipalFactory.cs
using System.Security.Claims;
using {:projectname:}.Entities.Identity;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;

namespace {:projectname:}.Data;

public sealed class BenutzerClaimsPrincipalFactory
    : UserClaimsPrincipalFactory<Benutzer, IdentityRole<long>>
{
    public BenutzerClaimsPrincipalFactory(
        UserManager<Benutzer> userManager,
        RoleManager<IdentityRole<long>> roleManager,
        IOptions<IdentityOptions> options)
        : base(userManager, roleManager, options) { }

    protected override async Task<ClaimsIdentity> GenerateClaimsAsync(Benutzer user)
    {
        var id = await base.GenerateClaimsAsync(user);
        id.AddClaim(new Claim(HttpContextTenantProvider.TenantClaimType, user.TenantNo));
        id.AddClaim(new Claim("{:lower(projectname):}:user_no", user.UserNo));
        id.AddClaim(new Claim("{:lower(projectname):}:display_name", user.DisplayName));
        return id;
    }
}