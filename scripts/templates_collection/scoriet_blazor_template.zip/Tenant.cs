// SCORIET-OUTPUT-PATH: {:projectname:}/Entities/Tenants/Tenant.cs
namespace {:projectname:}.Entities.Tenants;

public class Tenant
{
    public long TenantId { get; set; }
    public string TenantNo { get; set; } = default!;
    public string Name { get; set; } = default!;
    public string? ContactEmail { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}