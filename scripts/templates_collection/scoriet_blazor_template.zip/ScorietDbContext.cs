// SCORIET-OUTPUT-PATH: {:projectname:}/Data/{:projectname:}DbContext.cs
// Generic EF Core DbContext for the whole schema.
// Loops over every table in the schema to produce DbSets + OnModelCreating config.
using {:projectname:}.Entities.Common;
using {:projectname:}.Entities.Identity;
using {:projectname:}.Entities.Tenants;
{:for nmaxtables:}
using {:projectname:}.Entities.{:table.filepascalcase:};
{:endfor:}
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace {:projectname:}.Data;

public class {:projectname:}DbContext : IdentityDbContext<Benutzer, IdentityRole<long>, long>
{
    public {:projectname:}DbContext(DbContextOptions<{:projectname:}DbContext> options) : base(options) { }

    // Infrastructure tables (always present regardless of schema)
    public DbSet<Tenant> Tenants => Set<Tenant>();

    // One DbSet per schema table
    {:for nmaxtables:}
    public DbSet<{:table.filesingularpascalcase:}> {:table.filepascalcase:} => Set<{:table.filesingularpascalcase:}>();
    {:endfor:}

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        // --- Infrastructure ---

        b.Entity<Tenant>(e =>
        {
            e.ToTable("tenants");
            e.HasKey(t => t.TenantId);
            e.Property(t => t.TenantId).UseIdentityAlwaysColumn();
            e.Property(t => t.TenantNo).HasMaxLength(32).IsRequired();
            e.Property(t => t.Name).HasMaxLength(200).IsRequired();
            e.Property(t => t.ContactEmail).HasMaxLength(256);
            e.Property(t => t.CreatedAt).HasDefaultValueSql("now() at time zone 'utc'");
            e.HasAlternateKey(t => t.TenantNo);
            e.HasIndex(t => t.TenantNo).IsUnique();
        });

        b.Entity<Benutzer>(e =>
        {
            e.ToTable("users");
            e.Property(u => u.UserNo).HasMaxLength(32).IsRequired();
            e.Property(u => u.TenantNo).HasMaxLength(32).IsRequired();
            e.Property(u => u.DisplayName).HasMaxLength(200).IsRequired();
            e.Property(u => u.Color).HasMaxLength(9);

            e.HasOne<Tenant>().WithMany()
             .HasPrincipalKey(t => t.TenantNo).HasForeignKey(u => u.TenantNo)
             .OnDelete(DeleteBehavior.Restrict);

            e.HasIndex(u => u.UserNo).IsUnique();
        });

        // --- Generated tables ---

        {:for nmaxtables:}
        b.Entity<{:table.filesingularpascalcase:}>(e =>
        {
            e.ToTable("{:table.filename:}");
            {:if table.primarykeyfield:}
            e.HasKey(x => x.{:pascalcase(table.primarykeyfield):});
            {:endif:}
            {:for nmaxitems:}
            {:if item.isnullable:}
            e.Property(x => x.{:item.pascalcase:}){:if item.maxlength:}.HasMaxLength({:item.maxlength:}){:endif:};
            {:else:}
            e.Property(x => x.{:item.pascalcase:}){:if item.maxlength:}.HasMaxLength({:item.maxlength:}){:endif:}.IsRequired();
            {:endif:}
            {:endfor:}
            {:for nmaxforeignkeys:}
            e.HasOne<{:pascalcase(foreign.referencedtable):}>().WithMany()
             .HasForeignKey(x => x.{:pascalcase(foreign.name):})
             .OnDelete(DeleteBehavior.Restrict);
            {:endfor:}
            e.HasIndex(x => x.TenantNo);
        });
        {:endfor:}

        // Pluralised Identity tables
        b.Entity<IdentityRole<long>>().ToTable("roles");
        b.Entity<IdentityUserRole<long>>().ToTable("user_roles");
        b.Entity<IdentityUserClaim<long>>().ToTable("user_claims");
        b.Entity<IdentityUserLogin<long>>().ToTable("user_logins");
        b.Entity<IdentityRoleClaim<long>>().ToTable("role_claims");
        b.Entity<IdentityUserToken<long>>().ToTable("user_tokens");
    }
}