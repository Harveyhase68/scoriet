using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

// SCORIET-OUTPUT-PATH: {:projectname:}/Reports/PdfReportService.cs
namespace {:projectname:}.Reports;

/// <summary>
/// Two generic PDF builders used by every list and detail page:
///  - <see cref="BuildList"/> renders a simple landscape table report
///  - <see cref="BuildRecord"/> renders a label-value detail sheet
/// Both share header / footer styling so reports look consistent.
/// </summary>
public sealed class PdfReportService
{
    public byte[] BuildList(string title, string? subtitle, string[] headers,
        IEnumerable<string?[]> rows, float[]? relativeColumnWidths = null)
    {
        var rowList = rows.ToList();

        var doc = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4.Landscape());
                page.Margin(1.5f, Unit.Centimetre);
                page.DefaultTextStyle(t => t.FontSize(9));

                page.Header().Element(c => Header(c, title, subtitle));
                page.Content().PaddingVertical(0.5f, Unit.Centimetre).Table(table =>
                {
                    table.ColumnsDefinition(cols =>
                    {
                        if (relativeColumnWidths is not null && relativeColumnWidths.Length == headers.Length)
                            foreach (var w in relativeColumnWidths) cols.RelativeColumn(w);
                        else
                            for (var i = 0; i < headers.Length; i++) cols.RelativeColumn();
                    });

                    table.Header(h =>
                    {
                        foreach (var header in headers)
                            h.Cell().Background(Colors.Grey.Lighten3).Padding(4).Text(header).SemiBold();
                    });

                    var alt = false;
                    foreach (var row in rowList)
                    {
                        var bg = alt ? Colors.Grey.Lighten5 : Colors.White;
                        for (var i = 0; i < headers.Length; i++)
                        {
                            var value = i < row.Length ? row[i] ?? "" : "";
                            table.Cell().Background(bg).Padding(4).Text(value);
                        }
                        alt = !alt;
                    }
                });
                page.Footer().Element(Footer);
            });
        });

        using var ms = new MemoryStream();
        doc.GeneratePdf(ms);
        return ms.ToArray();
    }

    public byte[] BuildRecord(string title, string? subtitle,
        IEnumerable<(string Label, string? Value)> fields)
    {
        var fieldList = fields.ToList();

        var doc = Document.Create(container =>
        {
            container.Page(page =>
            {
                page.Size(PageSizes.A4);
                page.Margin(2, Unit.Centimetre);
                page.DefaultTextStyle(t => t.FontSize(10));

                page.Header().Element(c => Header(c, title, subtitle));
                page.Content().PaddingVertical(0.5f, Unit.Centimetre).Table(table =>
                {
                    table.ColumnsDefinition(c =>
                    {
                        c.ConstantColumn(170);
                        c.RelativeColumn();
                    });
                    foreach (var (label, value) in fieldList)
                    {
                        table.Cell().Background(Colors.Grey.Lighten5).Padding(6).Text(label).SemiBold();
                        table.Cell().Padding(6).Text(value ?? "");
                    }
                });
                page.Footer().Element(Footer);
            });
        });

        using var ms = new MemoryStream();
        doc.GeneratePdf(ms);
        return ms.ToArray();
    }

    private static void Header(IContainer container, string title, string? subtitle)
    {
        container.Column(col =>
        {
            col.Item().Row(r =>
            {
                r.RelativeItem().Column(c =>
                {
                    c.Item().Text(title).FontSize(16).Bold();
                    if (!string.IsNullOrEmpty(subtitle))
                        c.Item().Text(subtitle).FontSize(9).FontColor(Colors.Grey.Darken1);
                });
                r.ConstantItem(120).AlignRight().AlignMiddle()
                    .Text("{:projectname:}").FontSize(11).FontColor(Colors.Grey.Darken2);
            });
            col.Item().PaddingTop(4).LineHorizontal(0.5f).LineColor(Colors.Grey.Lighten1);
        });
    }

    private static void Footer(IContainer container)
    {
        container.AlignCenter().Text(t =>
        {
            t.Span($"gedruckt {DateTime.Now:dd.MM.yyyy HH:mm} · Seite ")
                .FontColor(Colors.Grey.Darken1).FontSize(8);
            t.CurrentPageNumber().FontColor(Colors.Grey.Darken1).FontSize(8);
            t.Span(" / ").FontColor(Colors.Grey.Darken1).FontSize(8);
            t.TotalPages().FontColor(Colors.Grey.Darken1).FontSize(8);
        });
    }
}