// SCORIET-OUTPUT-PATH: {:projectname:}/Entities/Common/TenantEntity.cs
namespace {:projectname:}.Entities.Common;

public abstract class TenantEntity
{
    public string TenantNo { get; set; } = default!;
}