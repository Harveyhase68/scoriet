Template: spring_boot_react_native
Description: Java Spring Boot with React Native

Test:

first shell:
mvnw.cmd spring-boot:run
second shell:
CD frontend
npx expo start

Mobile device, scan QR code, login admin/admin
Category: Mobile
Language: Spring
Creator: Scoriet System (office@scoriet.dev)
Created: 2026-06-09 16:52:06

Scoriet Template Export
https://scoriet.com
