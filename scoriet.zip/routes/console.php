<?php

use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    // Overrides the Laravel default
});
